<?php

get_header();

?>

    <main class="case-study-single">

        <?php

        if ( have_posts() ) :

            while ( have_posts() ) :

                the_post();

                $blocks =
                    get_post_meta(
                        get_the_ID(),
                        'case_study_blocks',
                        true
                    );

                $blocks =
                    json_decode(
                        $blocks,
                        true
                    );

                ?>

                <article
                    <?php post_class(); ?>
                >

                    <h1>
                        <?php the_title(); ?>
                    </h1>

                    <?php the_content(); ?>

                    <?php

                    if (
                        ! empty($blocks)
                        && is_array($blocks)
                    ) :

                        ?>

                        <div class="case-study-blocks">

                            <?php

                            foreach (
                                $blocks
                                as $block
                            ) :

                                ?>

                                <?php

                                if (
                                    $block['type']
                                    === 'title'
                                ) :

                                    ?>

                                    <h3
                                            class="case-study-block case-study-block--title"
                                    >
                                        <?php
                                        echo esc_html(
                                            $block['content']
                                        );
                                        ?>
                                    </h3>

                                <?php

                                endif;

                                ?>

                                <?php

                                if (
                                    $block['type']
                                    === 'blurb'
                                ) :

                                    ?>

                                    <div
                                            class="case-study-block case-study-block--blurb"
                                    >
                                        <?php
                                        echo wpautop(
                                            esc_html(
                                                $block['content']
                                            )
                                        );
                                        ?>
                                    </div>

                                <?php

                                endif;

                                ?>

                                <?php

                                if (
                                    $block['type']
                                    === 'images'
                                    && ! empty(
                                    $block['images']
                                    )
                                ) :

                                    $images_count =
                                        count(
                                            $block['images']
                                        );

                                    $grid_class =
                                        'case-study-images--3';

                                    if (
                                        $images_count === 1
                                    ) {

                                        $grid_class =
                                            'case-study-images--1';

                                    } elseif (
                                        $images_count === 2
                                    ) {

                                        $grid_class =
                                            'case-study-images--2';

                                    }

                                    ?>

                                    <div
                                            class="case-study-images <?php echo esc_attr($grid_class); ?>"
                                    >

                                        <?php

                                        foreach (
                                            $block['images']
                                            as $image_id
                                        ) :

                                            ?>

                                            <div
                                                    class="case-study-images__item"
                                            >

                                                <?php

                                                echo wp_get_attachment_image(
                                                    $image_id,
                                                    'large'
                                                );

                                                ?>

                                            </div>

                                        <?php

                                        endforeach;

                                        ?>

                                    </div>

                                <?php

                                endif;

                                ?>

                            <?php

                            endforeach;

                            ?>

                        </div>

                    <?php

                    endif;

                    ?>

                </article>

            <?php

            endwhile;

        endif;

        ?>

    </main>

<?php

get_footer();