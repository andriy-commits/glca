
<?php
/**
 * Title: Card Grid Section
 * Slug: glca/card-grid-section
 * Categories: glca
 * Description: Editable card grid using core blocks.
 */
?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|lg","bottom":"var:preset|spacing|lg"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--lg);padding-bottom:var(--wp--preset--spacing--lg)"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"className":"is-style-section-card"} -->
<div class="wp-block-column is-style-section-card"><!-- wp:heading {"level":3} --><h3 class="wp-block-heading">Card title</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Editable card text.</p><!-- /wp:paragraph --></div>
<!-- /wp:column --><!-- wp:column {"className":"is-style-section-card"} -->
<div class="wp-block-column is-style-section-card"><!-- wp:heading {"level":3} --><h3 class="wp-block-heading">Card title</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Editable card text.</p><!-- /wp:paragraph --></div>
<!-- /wp:column --><!-- wp:column {"className":"is-style-section-card"} -->
<div class="wp-block-column is-style-section-card"><!-- wp:heading {"level":3} --><h3 class="wp-block-heading">Card title</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Editable card text.</p><!-- /wp:paragraph --></div>
<!-- /wp:column --></div><!-- /wp:columns --></div>
<!-- /wp:group -->
