
<?php
/**
 * Title: FAQ Accordion Section
 * Slug: glca/faq-accordion-section
 * Categories: glca
 * Description: FAQ row using the custom Accordion block.
 */
?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|lg","bottom":"var:preset|spacing|lg"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--lg);padding-bottom:var(--wp--preset--spacing--lg)"><!-- wp:heading {"textAlign":"center","fontSize":"x-large"} -->
<h2 class="wp-block-heading has-text-align-center has-x-large-font-size">Frequently asked questions</h2>
<!-- /wp:heading -->
<!-- wp:glca/accordion {"title":"Accordion item title"} -->
<div class="wp-block-glca-accordion"><details><summary>Accordion item title</summary><div class="glca-accordion__content"><!-- wp:paragraph --><p>Add answer content here.</p><!-- /wp:paragraph --></div></details></div>
<!-- /wp:glca/accordion --></div>
<!-- /wp:group -->
