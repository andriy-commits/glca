<?php
/**
 * GLCA functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package GLCA
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function glca_setup() {
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on GLCA, use a find and replace
		* to change 'glca' to the name of your theme in all the template files.
		*/
	load_theme_textdomain( 'glca', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support( 'title-tag' );

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support( 'post-thumbnails' );

	// Gutenberg/editor support required by Groundwrk.
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
    add_theme_support( 'wp-block-styles' );
	add_editor_style( array( 'assets/css/main.css', 'assets/css/editor.css' ) );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__( 'Primary', 'glca' ),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'glca_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action( 'after_setup_theme', 'glca_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function glca_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'glca_content_width', 1500 );
}
add_action( 'after_setup_theme', 'glca_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function glca_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'glca' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'glca' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'glca_widgets_init' );

/**
 * Enqueue scripts and styles.
 */

function glca_slider_assets() {

    wp_enqueue_style(
        'slick-css',
        'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css',
        array(),
        null
    );

    wp_enqueue_script(
        'slick-js',
        'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js',
        array('jquery'),
        null,
        true
    );

    wp_enqueue_script(
        'swiper-js',

        'https://cdn.jsdelivr.net/npm/swiper@12/swiper-bundle.min.js',

        array(),

        null,

        true
    );

    wp_enqueue_style(
        'swiper-css',

        'https://cdn.jsdelivr.net/npm/swiper@12/swiper-bundle.min.css',

        array(),

        null
    );

    wp_enqueue_script(
        'glca-main-js',
        get_template_directory_uri() . '/assets/js/main.js',
        array('jquery', 'slick-js'),
        filemtime(
            get_template_directory() . '/assets/js/main.js'
        ),
        true
    );

}
add_action(
    'wp_enqueue_scripts',
    'glca_slider_assets'
);
function glca_scripts() {

    wp_enqueue_style(
        'glca-style',
        get_stylesheet_uri(),
        array(),
        filemtime( get_template_directory() . '/style.css' )
    );

    wp_style_add_data( 'glca-style', 'rtl', 'replace' );

    wp_enqueue_style(
        'glca-main',
        get_template_directory_uri() . '/assets/css/main.css',
        array( 'glca-style' ),
        filemtime( get_template_directory() . '/assets/css/main.css' )
    );

    wp_enqueue_script(
        'glca-main-js',
        get_template_directory_uri() . '/assets/js/main.js',
        [],
        filemtime(
            get_template_directory() . '/assets/js/main.js'
        ),
        true
    );

    wp_enqueue_script(
        'glca-accordion',
        get_template_directory_uri() . '/js/accordion.js',
        [],
        filemtime(
            get_template_directory() . '/js/accordion.js'
        ),
        true
    );


    wp_enqueue_script(
        'glca-navigation',
        get_template_directory_uri() . '/js/navigation.js',
        array(),
        filemtime( get_template_directory() . '/js/navigation.js' ),
        true
    );

    wp_enqueue_script(
        'glca-animations',
        get_template_directory_uri() . '/assets/js/animations.js',
        array(),
        filemtime( get_template_directory() . '/assets/js/animations.js' ),
        true
    );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'glca_scripts' );

/**
 * Enqueue editor-only styles for visual parity with the front end.
 */
function glca_editor_assets() {

    wp_enqueue_style(
        'glca-editor',
        get_template_directory_uri() . '/assets/css/editor.css',
        array( 'glca-main' ),
        filemtime( get_template_directory() . '/assets/css/editor.css' )
    );

}
add_action( 'enqueue_block_editor_assets', 'glca_editor_assets' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}



/**
 * Gutenberg blocks, block styles, and patterns.
 */
require get_template_directory() . '/inc/blocks.php';
require get_template_directory() . '/inc/block-styles.php';
require get_template_directory() . '/inc/block-patterns.php';
require get_template_directory()
    . '/inc/blocks/team-cards.php';



add_action( 'init', function() {

    register_block_style(
        'core/button',
        [
            'name'  => 'primary',
            'label' => 'Primary',
        ]
    );

} );

register_block_style(
    'core/button',
    [
        'name'  => 'outline-arrow',
        'label' => 'Outline Arrow',
    ]
);
add_action( 'init', function() {

    register_block_style(
        'core/button',
        [
            'name'  => 'text-arrow',
            'label' => 'Text Arrow',
        ]
    );

} );

add_theme_support( 'editor-styles' );

add_editor_style( 'assets/css/editor.css' );



register_block_style(
    'core/group',
    [
        'name'  => 'scheme-1',
        'label' => 'Scheme 1',
    ]
);

register_block_style(
    'core/group',
    [
        'name'  => 'scheme-2',
        'label' => 'Scheme 2',
    ]
);

require get_template_directory() . '/inc/post-types.php';
require get_template_directory() . '/inc/meta.php';
require get_template_directory() . '/inc/meta-team.php';



function glca_case_study_sidebar_assets() {

    $asset_file =
        include get_template_directory()
            . '/build/case-study-sidebar/index.asset.php';

    wp_enqueue_script(
        'glca-case-study-sidebar',
        get_template_directory_uri()
        . '/build/case-study-sidebar/index.js',
        $asset_file['dependencies'],
        $asset_file['version'],
        true
    );

}
add_action(
    'enqueue_block_editor_assets',
    'glca_case_study_sidebar_assets'
);


function glca_allow_svg_uploads(
    $mimes
) {

    $mimes['svg'] =
        'image/svg+xml';

    return $mimes;

}

add_filter(
    'upload_mimes',
    'glca_allow_svg_uploads'
);


require get_template_directory()
    . '/inc/blocks/case-study-acquired.php';


require get_template_directory() . '/inc/class-mega-menu-walker.php';


// Transaction sidebar meta
function glca_register_transaction_meta() {
    register_post_meta( 'transaction', 'transaction_blocks', [
        'show_in_rest' => true,
        'single'       => true,
        'type'         => 'string',
        'default'      => '[]',
    ] );
}
add_action( 'init', 'glca_register_transaction_meta' );

// Enqueue transaction sidebar script
function glca_transaction_sidebar_assets() {
    $screen = get_current_screen();
    if ( ! $screen || $screen->post_type !== 'transaction' ) return;

    $asset = include get_template_directory() . '/build/transaction-sidebar/index.asset.php';
    wp_enqueue_script(
        'glca-transaction-sidebar',
        get_template_directory_uri() . '/build/transaction-sidebar/index.js',
        $asset['dependencies'],
        $asset['version'],
        true
    );
}
add_action( 'enqueue_block_editor_assets', 'glca_transaction_sidebar_assets' );


add_filter( 'upload_mimes', function( $mimes ) {
    $mimes['vcf'] = 'text/vcard';
    return $mimes;
} );



// Register Blue Duotone block styles
add_action( 'init', function() {

    register_block_style( 'core/cover', [
        'name'  => 'glca-duotone',
        'label' => 'Blue Duotone',
    ] );

    register_block_style( 'core/image', [
        'name'  => 'glca-duotone',
        'label' => 'Blue Duotone',
    ] );

    register_block_style( 'core/video', [
        'name'  => 'glca-duotone',
        'label' => 'Blue Duotone',
    ] );

} );

// Inject SVG filter into footer
add_action( 'wp_footer', function() {
    ?>
    <svg style="position:absolute;width:0;height:0;overflow:hidden" aria-hidden="true" focusable="false">
        <defs>
            <filter id="glca-duotone-filter" color-interpolation-filters="sRGB" x="-10%" y="-10%" width="120%" height="120%">
                <feColorMatrix type="saturate" values="0" result="grey"/>
                <feColorMatrix in="grey" type="matrix"
                               values="0.917 0 0 0 0.020
                            0.891 0 0 0 0.082
                            0.675 0 0 0 0.325
                            0 0 0 1 0"/>
            </filter>
        </defs>
    </svg>
    <?php
} );

add_action( 'enqueue_block_editor_assets', function() {
    wp_add_inline_style( 'wp-edit-blocks', '
        .is-style-glca-duotone img,
        .is-style-glca-duotone .wp-block-cover__image-background,
        .is-style-glca-duotone .wp-block-cover__video-background {
            filter: grayscale(100%) sepia(40%) hue-rotate(185deg) saturate(3) brightness(0.85) !important;
        }
    ' );
} );


// Transaction Grid AJAX
add_action( 'wp_ajax_glca_transaction_grid', 'glca_transaction_grid_ajax' );
add_action( 'wp_ajax_nopriv_glca_transaction_grid', 'glca_transaction_grid_ajax' );

function glca_transaction_grid_ajax() {
    check_ajax_referer( 'glca_transaction_grid', 'nonce' );

    $posts_per_page = isset( $_POST['posts_per_page'] ) ? (int) $_POST['posts_per_page'] : 12;
    $paged          = isset( $_POST['paged'] ) ? (int) $_POST['paged'] : 1;
    $expertise      = isset( $_POST['expertise'] ) ? sanitize_text_field( $_POST['expertise'] ) : '';
    $industry       = isset( $_POST['industry'] ) ? sanitize_text_field( $_POST['industry'] ) : '';

    $tax_query = [];

    if ( $expertise ) {
        $tax_query[] = [
            'taxonomy' => 'transaction_expertise',
            'field'    => 'slug',
            'terms'    => $expertise,
        ];
    }

    if ( $industry ) {
        $tax_query[] = [
            'taxonomy' => 'transaction_industry',
            'field'    => 'slug',
            'terms'    => $industry,
        ];
    }

    if ( count( $tax_query ) > 1 ) {
        $tax_query['relation'] = 'AND';
    }

    $query = new WP_Query( [
        'post_type'      => 'transaction',
        'posts_per_page' => $posts_per_page,
        'paged'          => $paged,
        'tax_query'      => $tax_query,
    ] );

    $cards = [];

    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) {
            $query->the_post();
            $post_id = get_the_ID();
            $blocks  = json_decode( get_post_meta( $post_id, 'transaction_blocks', true ) ?: '[]', true );

            ob_start();
            ?>
            <a href="<?php the_permalink(); ?>" class="transaction-card">
                <div class="transaction-card__inner">
                    <?php foreach ( $blocks as $block ) :
                        $margin = isset( $block['marginBottom'] ) ? (int) $block['marginBottom'] : 16;

                        if ( $block['type'] === 'title' ) : ?>
                            <div class="transaction-card__title" style="margin-bottom: <?php echo esc_attr( $margin ); ?>px">
                                <span><?php echo esc_html( $block['content'] ); ?></span>
                            </div>

                        <?php elseif ( $block['type'] === 'blurb' ) : ?>
                            <p class="transaction-card__blurb" style="margin-bottom: <?php echo esc_attr( $margin ); ?>px">
                                <?php echo esc_html( $block['content'] ); ?>
                            </p>

                        <?php elseif ( $block['type'] === 'images' && ! empty( $block['images'] ) ) :
                            $count      = count( $block['images'] );
                            $cols_class = $count === 1 ? 'is-single' : ( $count === 2 ? 'is-double' : 'is-triple' );
                            $size_class = ! empty( $block['size'] ) ? 'is-size-' . sanitize_html_class( $block['size'] ) : 'is-size-medium';
                            ?>
                            <div class="transaction-card__images <?php echo esc_attr( $cols_class ); ?> <?php echo esc_attr( $size_class ); ?>" style="margin-bottom: <?php echo esc_attr( $margin ); ?>px">
                                <?php foreach ( $block['images'] as $img ) : ?>
                                    <div class="transaction-card__image-wrap">
                                        <img class="transaction-card__img--white"
                                             src="<?php echo esc_url( $img['url'] ); ?>"
                                             alt="<?php echo esc_attr( $img['alt'] ); ?>">
                                        <?php if ( ! empty( $img['urlColor'] ) ) : ?>
                                            <img class="transaction-card__img--color"
                                                 src="<?php echo esc_url( $img['urlColor'] ); ?>"
                                                 alt="<?php echo esc_attr( $img['alt'] ); ?>">
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </a>
            <?php
            $cards[] = ob_get_clean();
        }
        wp_reset_postdata();
    }

    wp_send_json_success( [
        'cards'      => $cards,
        'total'      => (int) $query->found_posts,
        'max_pages'  => (int) $query->max_num_pages,
        'paged'      => $paged,
    ] );
}

// Localize AJAX url
add_action( 'wp_enqueue_scripts', function() {
    wp_localize_script( 'glca-main-js', 'glcaAjax', [
        'url'   => admin_url( 'admin-ajax.php' ),
        'nonce' => wp_create_nonce( 'glca_transaction_grid' ),
    ] );
} );


// Disable comments on pages and posts
add_action( 'init', function() {
    remove_post_type_support( 'page', 'comments' );
    remove_post_type_support( 'post', 'comments' );
} );