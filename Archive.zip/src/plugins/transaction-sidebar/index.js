const { registerPlugin } = wp.plugins;
const { PluginDocumentSettingPanel } = wp.editor;
const { Button, TextControl, TextareaControl, SelectControl } = wp.components;
const { useSelect, useDispatch } = wp.data;
const { Fragment } = wp.element;

function TransactionSidebar() {

    const meta = useSelect(
        ( select ) => select( 'core/editor' ).getEditedPostAttribute( 'meta' ),
        []
    );

    const { editPost } = useDispatch( 'core/editor' );

    let blocks = [];
    try {
        blocks = JSON.parse( meta.transaction_blocks || '[]' );
    } catch ( e ) {}

    function updateBlocks( newBlocks ) {
        editPost( {
            meta: {
                ...meta,
                transaction_blocks: JSON.stringify( newBlocks ),
            },
        } );
    }

    function addTitle() {
        updateBlocks( [ ...blocks, { type: 'title', content: '', marginBottom: 16 } ] );
    }

    function addBlurb() {
        updateBlocks( [ ...blocks, { type: 'blurb', content: '', marginBottom: 16 } ] );
    }

    function addImages() {
        const frame = wp.media( {
            title: 'Select White Logos',
            button: { text: 'Add Images' },
            multiple: true,
        } );

        frame.on( 'select', () => {
            const attachments = frame.state().get( 'selection' ).map(
                ( attachment ) => ( {
                    id: attachment.id,
                    url: attachment.attributes.url,
                    alt: attachment.attributes.alt || '',
                    urlColor: '',
                } )
            );

            updateBlocks( [
                ...blocks,
                { type: 'images', images: attachments, size: 'medium', marginBottom: 16 },
            ] );
        } );

        frame.open();
    }

    function removeBlock( index ) {
        const updated = blocks.filter( ( _, i ) => i !== index );
        updateBlocks( updated );
    }

    function moveBlock( index, direction ) {
        const updated = [ ...blocks ];
        const target  = index + direction;
        if ( target < 0 || target >= updated.length ) return;
        [ updated[ index ], updated[ target ] ] = [ updated[ target ], updated[ index ] ];
        updateBlocks( updated );
    }

    function addColorImage( blockIndex, imgIndex ) {
        const frame = wp.media( {
            title: 'Select Color Logo',
            button: { text: 'Select' },
            multiple: false,
        } );

        frame.on( 'select', () => {
            const attachment = frame.state().get( 'selection' ).first();
            const updated = [ ...blocks ];
            updated[ blockIndex ].images[ imgIndex ].urlColor = attachment.attributes.url;
            updateBlocks( updated );
        } );

        frame.open();
    }

    return (
        <PluginDocumentSettingPanel
            name="transaction-panel"
            title="Transaction Content"
        >
            <div style={ { display: 'flex', gap: '6px', marginBottom: '12px', flexWrap: 'wrap' } }>
                <Button variant="primary" onClick={ addTitle }>
                    + Title
                </Button>
                <Button variant="secondary" onClick={ addBlurb }>
                    + Blurb
                </Button>
                <Button variant="secondary" onClick={ addImages }>
                    + Images
                </Button>
            </div>

            { blocks.map( ( block, index ) => (
                <Fragment key={ index }>
                    <div style={ {
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        padding: '10px',
                        marginBottom: '8px',
                        background: '#f9f9f9',
                    } }>

                        <div style={ { display: 'flex', justifyContent: 'space-between', marginBottom: '8px' } }>
                            <span style={ { fontSize: '11px', color: '#888', textTransform: 'uppercase' } }>
                                { block.type }
                            </span>
                            <div style={ { display: 'flex', gap: '4px' } }>
                                <Button
                                    isSmall
                                    variant="tertiary"
                                    onClick={ () => moveBlock( index, -1 ) }
                                    disabled={ index === 0 }
                                >↑</Button>
                                <Button
                                    isSmall
                                    variant="tertiary"
                                    onClick={ () => moveBlock( index, 1 ) }
                                    disabled={ index === blocks.length - 1 }
                                >↓</Button>
                                <Button
                                    isSmall
                                    isDestructive
                                    onClick={ () => removeBlock( index ) }
                                >✕</Button>
                            </div>
                        </div>

                        { /* Margin bottom control for all block types */ }
                        <div style={ { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' } }>
                            <span style={ { fontSize: '11px', color: '#555' } }>Margin bottom (px)</span>
                            <input
                                type="number"
                                value={ block.marginBottom !== undefined ? block.marginBottom : 16 }
                                min="0"
                                max="120"
                                style={ { width: '60px', fontSize: '12px', padding: '2px 4px' } }
                                onChange={ ( e ) => {
                                    const updated = [ ...blocks ];
                                    updated[ index ].marginBottom = parseInt( e.target.value ) || 0;
                                    updateBlocks( updated );
                                } }
                            />
                        </div>

                        { block.type === 'title' && (
                            <TextControl
                                label="Title text"
                                value={ block.content }
                                onChange={ ( value ) => {
                                    const updated = [ ...blocks ];
                                    updated[ index ].content = value;
                                    updateBlocks( updated );
                                } }
                            />
                        ) }

                        { block.type === 'blurb' && (
                            <TextareaControl
                                label="Blurb text"
                                value={ block.content }
                                onChange={ ( value ) => {
                                    const updated = [ ...blocks ];
                                    updated[ index ].content = value;
                                    updateBlocks( updated );
                                } }
                            />
                        ) }

                        { block.type === 'images' && (
                            <div>
                                <SelectControl
                                    label="Logo size"
                                    value={ block.size || 'medium' }
                                    options={ [
                                        { label: 'Small', value: 'small' },
                                        { label: 'Medium', value: 'medium' },
                                        { label: 'Large', value: 'large' },
                                    ] }
                                    onChange={ ( value ) => {
                                        const updated = [ ...blocks ];
                                        updated[ index ].size = value;
                                        updateBlocks( updated );
                                    } }
                                    style={ { marginBottom: '8px' } }
                                />

                                <div style={ { display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '8px' } }>
                                    { block.images.map( ( img, imgIndex ) => (
                                        <div key={ imgIndex } style={ { position: 'relative', marginBottom: '8px' } }>

                                            <div style={ { fontSize: '10px', color: '#555', marginBottom: '2px' } }>White</div>
                                            <div style={ { position: 'relative', display: 'inline-block' } }>
                                                <img
                                                    src={ img.url }
                                                    alt={ img.alt }
                                                    style={ { width: '60px', height: '60px', objectFit: 'contain', background: '#002440' } }
                                                />
                                                <Button
                                                    isSmall
                                                    isDestructive
                                                    style={ { position: 'absolute', top: 0, right: 0, minWidth: 'auto', padding: '2px' } }
                                                    onClick={ () => {
                                                        const updated = [ ...blocks ];
                                                        updated[ index ].images = block.images.filter( ( _, i ) => i !== imgIndex );
                                                        updateBlocks( updated );
                                                    } }
                                                >✕</Button>
                                            </div>

                                            <div style={ { fontSize: '10px', color: '#555', marginTop: '4px', marginBottom: '2px' } }>Color (hover)</div>
                                            { img.urlColor ? (
                                                <div style={ { position: 'relative', display: 'inline-block' } }>
                                                    <img
                                                        src={ img.urlColor }
                                                        alt=""
                                                        style={ { width: '60px', height: '60px', objectFit: 'contain', background: '#fff' } }
                                                    />
                                                    <Button
                                                        isSmall
                                                        isDestructive
                                                        style={ { position: 'absolute', top: 0, right: 0, minWidth: 'auto', padding: '2px' } }
                                                        onClick={ () => {
                                                            const updated = [ ...blocks ];
                                                            updated[ index ].images[ imgIndex ].urlColor = '';
                                                            updateBlocks( updated );
                                                        } }
                                                    >✕</Button>
                                                </div>
                                            ) : (
                                                <Button
                                                    variant="secondary"
                                                    isSmall
                                                    onClick={ () => addColorImage( index, imgIndex ) }
                                                >
                                                    + Add color
                                                </Button>
                                            ) }

                                        </div>
                                    ) ) }
                                </div>

                                <Button
                                    variant="secondary"
                                    isSmall
                                    onClick={ () => {
                                        const frame = wp.media( {
                                            title: 'Add More Images',
                                            button: { text: 'Add' },
                                            multiple: true,
                                        } );
                                        frame.on( 'select', () => {
                                            const newImages = frame.state().get( 'selection' ).map(
                                                ( a ) => ( { id: a.id, url: a.attributes.url, alt: a.attributes.alt || '', urlColor: '' } )
                                            );
                                            const updated = [ ...blocks ];
                                            updated[ index ].images = [ ...block.images, ...newImages ];
                                            updateBlocks( updated );
                                        } );
                                        frame.open();
                                    } }
                                >
                                    + Add more images
                                </Button>
                            </div>
                        ) }

                    </div>
                </Fragment>
            ) ) }

        </PluginDocumentSettingPanel>
    );
}

registerPlugin( 'glca-transaction-sidebar', { render: TransactionSidebar } );