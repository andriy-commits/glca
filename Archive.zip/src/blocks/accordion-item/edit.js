import {
    InnerBlocks,
    useBlockProps,
} from '@wordpress/block-editor';

export default function Edit() {

    const blockProps = useBlockProps({
        className: 'accordion-item',
    });

    return (
        <div {...blockProps}>

            <div className="accordion-item__left">

                <InnerBlocks
                    template={[
                        [
                            'core/heading',
                            {
                                level: 3,
                                content: 'Accordion Title',
                            },
                        ],
                        [
                            'core/paragraph',
                            {
                                content:
                                    'Accordion content text.',
                            },
                        ],
                        [
                            'core/buttons',
                        ],
                    ]}
                />

            </div>

            <div className="accordion-item__right">

                <InnerBlocks
                    template={[
                        [
                            'core/image',
                        ],
                    ]}
                    templateLock="all"
                />

            </div>

        </div>
    );
}