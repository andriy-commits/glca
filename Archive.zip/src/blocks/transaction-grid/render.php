<?php
/**
 * Transaction Grid block render
 *
 * @package GLCA
 */

$posts_per_page = ! empty( $attributes['postsPerPage'] ) ? (int) $attributes['postsPerPage'] : 12;

$expertise_terms = get_terms( [ 'taxonomy' => 'transaction_expertise', 'hide_empty' => true ] );
$industry_terms  = get_terms( [ 'taxonomy' => 'transaction_industry', 'hide_empty' => true ] );

$active_expertise = isset( $_GET['expertise'] ) ? sanitize_text_field( $_GET['expertise'] ) : '';
$active_industry  = isset( $_GET['industry'] ) ? sanitize_text_field( $_GET['industry'] ) : '';
?>

<div class="transaction-grid"
    <?php echo get_block_wrapper_attributes(); ?>
     data-posts-per-page="<?php echo esc_attr( $posts_per_page ); ?>"
>

    <div class="transaction-grid__filters">
        <p class="transaction-grid__filters-label">
            <?php esc_html_e( 'Showing', 'glca' ); ?>

            <?php if ( $expertise_terms ) : ?>
                <select class="transaction-grid__select" data-filter="expertise">
                    <option value=""><?php esc_html_e( 'all', 'glca' ); ?></option>
                    <?php foreach ( $expertise_terms as $term ) : ?>
                        <option value="<?php echo esc_attr( $term->slug ); ?>"
                            <?php selected( $active_expertise, $term->slug ); ?>>
                            <?php echo esc_html( $term->name ); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            <?php endif; ?>

            <?php esc_html_e( 'transactions in', 'glca' ); ?>

            <?php if ( $industry_terms ) : ?>
                <select class="transaction-grid__select" data-filter="industry">
                    <option value=""><?php esc_html_e( 'every', 'glca' ); ?></option>
                    <?php foreach ( $industry_terms as $term ) : ?>
                        <option value="<?php echo esc_attr( $term->slug ); ?>"
                            <?php selected( $active_industry, $term->slug ); ?>>
                            <?php echo esc_html( $term->name ); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            <?php endif; ?>

            <?php esc_html_e( 'industry.', 'glca' ); ?>
        </p>
    </div>

    <div class="transaction-grid__grid"></div>

    <nav class="transaction-grid__pagination" aria-label="Transactions pagination">
        <div class="transaction-grid__pagination-inner">
            <div class="transaction-grid__pagination-numbers"></div>
            <div class="transaction-grid__pagination-arrows"></div>
        </div>
    </nav>

    <p class="transaction-grid__empty" style="display:none">
        <?php esc_html_e( 'No transactions found.', 'glca' ); ?>
    </p>

</div>