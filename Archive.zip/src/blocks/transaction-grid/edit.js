import { useBlockProps, InspectorControls } from '@wordpress/block-editor';
import { PanelBody, RangeControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';

export default function Edit( { attributes, setAttributes } ) {
    const blockProps = useBlockProps();

    return (
        <>
            <InspectorControls>
                <PanelBody title={ __( 'Settings', 'glca' ) }>
                    <RangeControl
                        label={ __( 'Posts per page', 'glca' ) }
                        value={ attributes.postsPerPage }
                        onChange={ ( value ) => setAttributes( { postsPerPage: value } ) }
                        min={ 4 }
                        max={ 48 }
                    />
                </PanelBody>
            </InspectorControls>
            <div { ...blockProps }>
                <p>{ __( 'Transaction Grid — renders on the front end.', 'glca' ) }</p>
            </div>
        </>
    );
}