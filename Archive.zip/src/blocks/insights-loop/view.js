jQuery(function($){

    function loadPosts(
        section,
        page=1
    ){

        $.ajax({

            url:

                section.data(
                    'ajaxurl'
                ),

            type:

                'POST',

            data:{

                action:

                    'insights_filter',

                cat:

                    section
                        .find(
                            '.is-active'
                        )
                        .data(
                            'cat'
                        ),

                page:

                page,

                nonce:

                    section.data(
                        'nonce'
                    )

            },

            success:function(
                response
            ){

                section
                    .find(
                        '.insights-posts-wrapper'
                    )
                    .html(
                        response
                    );

            }

        });

    }

    $('.insights-loop-section').each(
        function(){

            loadPosts(
                $(this)
            );

        }
    );

    $(document).on(

        'click',

        '.insights-filter__btn',

        function(){

            const section =
                $(this)
                    .closest(
                        '.insights-loop-section'
                    );

            section
                .find(
                    '.insights-filter__btn'
                )
                .removeClass(
                    'is-active'
                );

            $(this)
                .addClass(
                    'is-active'
                );

            loadPosts(
                section
            );

        }

    );

});