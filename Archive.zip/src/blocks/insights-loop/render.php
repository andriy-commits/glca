<?php

$categories =
    get_categories();

?>

<section
    class="insights-loop-section"

    data-ajaxurl="<?php echo admin_url(
        'admin-ajax.php'
    ); ?>"

    data-nonce="<?php echo wp_create_nonce(
        'insights_nonce'
    ); ?>"

>

    <div class="insights-filters">

        <button
            class="insights-filter__btn is-active"
            data-cat="">

            All

        </button>

        <?php foreach(
            $categories as $cat
        ): ?>

            <button
                class="insights-filter__btn"
                data-cat="<?php echo $cat->term_id; ?>">

                <?php echo esc_html(
                    $cat->name
                ); ?>

            </button>

        <?php endforeach; ?>

    </div>

    <div
        class="insights-posts-wrapper"

    ></div>

</section>


