<?php
/**
 * Team Grid block render
 *
 * @package GLCA
 */

// Get all cities
$cities = get_terms( array(
    'taxonomy'   => 'cities',
    'hide_empty' => true,
) );

// Get all positions
$positions = get_terms( array(
    'taxonomy'   => 'positions',
    'hide_empty' => true,
) );

// Get all team members
$team_query = new WP_Query( array(
    'post_type'      => 'team_members',
    'posts_per_page' => -1,
    'orderby'        => 'date',
    'order'          => 'ASC',
) );
?>
<?php
$section_title = ! empty( $attributes['sectionTitle'] ) ? $attributes['sectionTitle'] : __( 'Our Team', 'glca' );
?>
<div class="team-grid" <?php echo get_block_wrapper_attributes(); ?>>

    <?php if ( $cities || $positions ) : ?>
        <div class="team-grid__filters">

            <p class="team-grid__filters-label">
                <?php esc_html_e( 'Showing', 'glca' ); ?>

                <?php if ( $positions ) : ?>
                    <select class="team-grid__select" data-filter="position">
                        <option value="all"><?php esc_html_e( 'All Titles', 'glca' ); ?></option>
                        <?php foreach ( $positions as $position ) : ?>
                            <option value="<?php echo esc_attr( $position->slug ); ?>">
                                <?php echo esc_html( $position->name ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                <?php endif; ?>

                <?php esc_html_e( 'in', 'glca' ); ?>

                <?php if ( $cities ) : ?>
                    <select class="team-grid__select" data-filter="city">
                        <option value="all"><?php esc_html_e( 'All Offices', 'glca' ); ?></option>
                        <?php foreach ( $cities as $city ) : ?>
                            <option value="<?php echo esc_attr( $city->slug ); ?>">
                                <?php echo esc_html( $city->name ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                <?php endif; ?>

                .
            </p>

        </div>
    <?php endif; ?>

    <?php if ( $team_query->have_posts() ) : ?>
        <div class="team-grid__grid">
            <?php // Title cell — first column ?>
            <div class="team-grid__title-cell">
                <h2 class="team-grid__title"><?php esc_html_e( 'Our Team', 'glca' ); ?></h2>
            </div>
            <?php while ( $team_query->have_posts() ) : $team_query->the_post(); ?>
                <?php
                $member_id         = get_the_ID();
                $career_highlights = get_post_meta( $member_id, '_career_highlights', true );
                $education         = get_post_meta( $member_id, '_education', true );
                $vcard_url         = get_post_meta( $member_id, '_vcard_url', true );
                $excerpt = get_post_field( 'post_content', $member_id );
                $excerpt = wp_strip_all_tags( $excerpt );

                $member_cities    = wp_get_post_terms( $member_id, 'cities' );
                $member_positions = wp_get_post_terms( $member_id, 'positions' );

                $city_slugs     = implode( ' ', wp_list_pluck( $member_cities, 'slug' ) );
                $position_slugs = implode( ' ', wp_list_pluck( $member_positions, 'slug' ) );

                $city_name     = $member_cities ? $member_cities[0]->name : '';
                $position_name = $member_positions ? $member_positions[0]->name : '';
                ?>
                <div
                    class="team-grid__member"
                    data-city="<?php echo esc_attr( $city_slugs ); ?>"
                    data-position="<?php echo esc_attr( $position_slugs ); ?>"
                    data-id="<?php echo esc_attr( $member_id ); ?>"
                    role="button"
                    tabindex="0"
                    aria-label="<?php echo esc_attr( get_the_title() ); ?>"
                >
                    <?php if ( has_post_thumbnail() ) : ?>
                        <div class="team-grid__member-image">
                            <?php the_post_thumbnail( 'medium' ); ?>
                        </div>
                    <?php else : ?>
                        <div class="team-grid__member-image">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/placeholder-person.svg" alt="">
                        </div>
                    <?php endif; ?>

                    <div class="team-grid__member-info">
                        <h6 class="team-grid__member-name"><?php the_title(); ?></h6>
                        <?php if ( $position_name || $city_name ) : ?>
                            <p class="team-grid__member-meta">
                                <?php echo esc_html( implode( ' / ', array_filter( [ $position_name, $city_name ] ) ) ); ?>
                            </p>
                        <?php endif; ?>
                    </div>

                    <?php // Hidden modal data ?>
                    <div class="team-grid__modal-data" hidden>
                        <span class="modal-name"><?php the_title(); ?></span>
                        <span class="modal-position"><?php echo esc_html( $position_name ); ?></span>
                        <span class="modal-city"><?php echo esc_html( $city_name ); ?></span>
                        <span class="modal-excerpt"><?php echo esc_html( $excerpt ); ?></span>
                        <span class="modal-career"><?php echo esc_html( $career_highlights ); ?></span>
                        <span class="modal-education"><?php echo esc_html( $education ); ?></span>
                        <span class="modal-vcard"><?php echo esc_url( $vcard_url ); ?></span>
                        <span class="modal-image"><?php echo get_the_post_thumbnail_url( $member_id, 'medium_large' ); ?></span>
                    </div>

                </div>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
    <?php endif; ?>

</div>

<?php // Modal ?>
<div class="team-modal" id="team-modal" aria-hidden="true" role="dialog">
    <div class="team-modal__backdrop"></div>
    <div class="team-modal__inner">
        <div class="team-modal__close-wrap">
            <div class="wp-block-button is-style-outline-arrow">
                <button class="team-modal__close">
                    <?php esc_html_e( 'Close', 'glca' ); ?>
                </button>
            </div>
        </div>

        <div class="team-modal__content">
            <div class="team-modal__left">
                <div class="team-modal__image"></div>
            </div>
            <div class="team-modal__right">
                <div class="team-modal__header">
                    <h3 class="team-modal__name"></h3>
                    <p class="team-modal__meta"></p>
                </div>

                <div class="team-modal__right-inner">

                    <div class="team-modal__left-col">
                        <p class="team-modal__excerpt"></p>
                        <div class="team-modal__vcard-wrap">
                            <a class="team-modal__vcard wp-block-button__link" href="#" download>
                                <?php esc_html_e( 'Download V Card', 'glca' ); ?>
                            </a>
                        </div>
                    </div>

                    <div class="team-modal__right-col">
                        <div class="team-modal__details">
                            <div class="team-modal__detail-section">
                                <button class="team-modal__detail-toggle" aria-expanded="false">
                                    <?php esc_html_e( 'Career Highlights', 'glca' ); ?>
                                    <span class="team-modal__detail-icon" aria-hidden="true"></span>
                                </button>
                                <div class="team-modal__detail-body" hidden>
                                    <div class="team-modal__career"></div>
                                </div>
                            </div>
                            <div class="team-modal__detail-section">
                                <button class="team-modal__detail-toggle" aria-expanded="false">
                                    <?php esc_html_e( 'Education', 'glca' ); ?>
                                    <span class="team-modal__detail-icon" aria-hidden="true"></span>
                                </button>
                                <div class="team-modal__detail-body" hidden>
                                    <div class="team-modal__education"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>