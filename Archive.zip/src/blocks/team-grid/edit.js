import { useBlockProps, RichText } from '@wordpress/block-editor';
import { __ } from '@wordpress/i18n';

export default function Edit( { attributes, setAttributes } ) {
    const blockProps = useBlockProps( { className: 'team-grid-editor' } );

    return (
        <div { ...blockProps }>
            <RichText
                tagName="h2"
                className="team-grid__title"
                value={ attributes.sectionTitle }
                onChange={ ( value ) => setAttributes( { sectionTitle: value } ) }
                placeholder={ __( 'Our Team', 'glca' ) }
            />
            <p style={ { opacity: 0.5, fontSize: '14px' } }>
                { __( 'Team grid renders on the front end.', 'glca' ) }
            </p>
        </div>
    );
}