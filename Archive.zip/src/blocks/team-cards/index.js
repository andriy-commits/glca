import {
    registerBlockType
} from '@wordpress/blocks';

import {
    MediaUpload,
    MediaUploadCheck
} from '@wordpress/block-editor';

import {
    Button
} from '@wordpress/components';

import './style.scss';

registerBlockType(
    'glca/team-cards',

    {

        title:
            'Team Cards',

        icon:
            'images-alt2',

        category:
            'widgets',

        attributes: {

            images: {

                type:
                    'array',

                default:
                    []

            }

        },

        edit({

                 attributes,

                 setAttributes

             }) {

            return (

                <div className="team-cards-editor">

                    <MediaUploadCheck>

                        <MediaUpload

                            multiple

                            gallery

                            value={
                                attributes.images
                            }

                            onSelect={

                                (
                                    media
                                ) => {

                                    setAttributes({

                                        images:
                                        media

                                    });

                                }

                            }

                            render={

                                ({
                                     open
                                 }) => (

                                    <Button

                                        variant="primary"

                                        onClick={
                                            open
                                        }

                                    >

                                        Select Images

                                    </Button>

                                )

                            }

                        />

                    </MediaUploadCheck>

                    <div className="team-cards-stack">

                        {

                            attributes.images.map(

                                (
                                    image,
                                    i
                                ) => (

                                    <div

                                        key={
                                            image.id
                                        }

                                        className="team-card"

                                        style={{

                                            transform:

                                                `translateY(${i*18}px)`

                                        }}

                                    >

                                        <img

                                            src={
                                                image.url
                                            }

                                        />

                                    </div>

                                )

                            )

                        }

                    </div>

                </div>

            );

        },

        save() {

            return null;

        }

    }

);