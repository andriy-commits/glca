import { useBlockProps } from '@wordpress/block-editor';
import { __ } from '@wordpress/i18n';

export default function Edit() {
    const blockProps = useBlockProps( {
        className: 'insights-filter',
    } );

    return (
        <div { ...blockProps }>
            <p className="insights-filter__placeholder">
                { __( 'Insights Filter — category buttons will appear here on the front end.', 'glca' ) }
            </p>
        </div>
    );
}