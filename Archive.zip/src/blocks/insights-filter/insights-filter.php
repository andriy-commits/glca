<?php

function glca_register_insights_filter_block(){

    $asset =
        include(

            get_template_directory()

            .'/build/insights-filter/index.asset.php'

        );

    wp_register_script(

        'glca-insights-filter',

        get_template_directory_uri()

        .'/build/insights-filter/index.js',

        $asset['dependencies'],

        $asset['version']

    );

    register_block_type(

        'glca/insights-filter',

        [

            'editor_script'=>

                'glca-insights-filter',

            'render_callback'=>

                'glca_render_insights_filter'

        ]

    );

}

add_action(
    'init',
    'glca_register_insights_filter_block'
);

function glca_render_insights_filter(){

    return '<div>Insights Filter Works</div>';

}