import { registerBlockType }
    from '@wordpress/blocks';

import './style.scss';

registerBlockType(
    'glca/case-study-acquired',
    {
        title: 'Case Study Acquired',

        icon: 'images-alt2',

        category: 'widgets',

        edit() {

            return (

                <div className="case-study-acquired">

                    <div className="case-study-acquired__logo">

                        <img
                            src="/wp-content/themes/glca/assets/images/placeholder.png"
                            alt=""
                        />

                    </div>

                    <h3 className="case-study-acquired__title">
                        ACQUIRED BY
                    </h3>

                    <div className="case-study-acquired__logo">

                        <img
                            src="/wp-content/themes/glca/assets/images/placeholder.png"
                            alt=""
                        />

                    </div>

                </div>

            );

        },

        save() {
            return null;
        },
    }
);