<?php

$post_id = get_the_ID();

$blocks =
    get_post_meta(
        $post_id,
        'case_study_blocks',
        true
    );

$blocks =
    json_decode(
        $blocks,
        true
    );

if (
    empty($blocks)
    || ! is_array($blocks)
) {
    return;
}

$title = '';
$images = [];

foreach (
    $blocks as $block
) {

    if (
        empty($title)
        && $block['type'] === 'title'
    ) {

        $title =
            $block['content'];

    }

    if (
        empty($images)
        && $block['type'] === 'images'
    ) {

        $images =
            $block['images'];

    }

}

if (
    empty($title)
    && empty($images)
) {
    return;
}

?>

<div class="case-study-acquired">

    <?php if ($title) : ?>

        <h3
            class="case-study-acquired__title"
        >
            <?php
            echo esc_html(
                $title
            );
            ?>
        </h3>

    <?php endif; ?>

    <?php if ($images) : ?>

        <div
            class="case-study-acquired__logos case-study-acquired__logos--<?php echo esc_attr(count($images)); ?>"
        >

            <?php

            foreach (
                $images as $image_id
            ) :

                ?>

                <div
                    class="case-study-acquired__logo"
                >

                    <?php

                    echo wp_get_attachment_image(
                        $image_id,
                        'medium'
                    );

                    ?>

                </div>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

</div>