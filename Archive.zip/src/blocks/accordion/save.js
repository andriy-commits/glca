import {
    useBlockProps,
} from '@wordpress/block-editor';

export default function save({
                                 attributes,
                             }) {

    const {
        title,
        description,
        imageUrl,
        openByDefault,
    } = attributes;

    const blockProps = useBlockProps.save({
        className: `glca-accordion ${
            openByDefault ? 'is-open' : ''
        }`,
    });

    return (
        <div {...blockProps}>

            <div className="glca-accordion__grid">

                <div className="glca-accordion__left">

                    <h5 className="glca-accordion__title js-accordion-trigger">

                        {title}

                    </h5>

                    <div className="glca-accordion__content">

                        <p className="glca-accordion__description">

                            {description}

                        </p>

                    </div>

                </div>

                <div className="glca-accordion__right">

                    {imageUrl && (

                        <img
                            src={imageUrl}
                            alt=""
                        />

                    )}

                </div>

            </div>

        </div>
    );
}