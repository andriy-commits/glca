import { __ } from '@wordpress/i18n';

import {
    RichText,
    useBlockProps,
    InspectorControls,
    MediaUpload,
    MediaUploadCheck,
} from '@wordpress/block-editor';

import {
    PanelBody,
    ToggleControl,
} from '@wordpress/components';

export default function Edit({
                                 attributes,
                                 setAttributes,
                             }) {

    const {
        title,
        description,
        imageUrl,
        openByDefault,
    } = attributes;

    const blockProps = useBlockProps({
        className: `glca-accordion ${
            openByDefault ? 'is-open' : ''
        }`,
    });

    return (
        <div {...blockProps}>

            <InspectorControls>

                <PanelBody
                    title={__(
                        'Accordion settings',
                        'glca'
                    )}
                >

                    <ToggleControl
                        label={__(
                            'Open by default',
                            'glca'
                        )}
                        checked={openByDefault}
                        onChange={(value) =>
                            setAttributes({
                                openByDefault: value,
                            })
                        }
                    />

                </PanelBody>

            </InspectorControls>

            <div className="glca-accordion__grid">

                <div className="glca-accordion__left">

                    <RichText
                        tagName="h5"
                        className="glca-accordion__title"
                        value={title}
                        allowedFormats={[]}
                        placeholder={__(
                            'Accordion title…',
                            'glca'
                        )}
                        onClick={() =>
                            setAttributes({
                                openByDefault:
                                    !openByDefault,
                            })
                        }
                        onChange={(value) =>
                            setAttributes({
                                title: value,
                            })
                        }
                    />

                    <div className="glca-accordion__content">

                        <RichText
                            tagName="p"
                            className="glca-accordion__description"
                            value={description}
                            placeholder={__(
                                'Accordion text…',
                                'glca'
                            )}
                            onChange={(value) =>
                                setAttributes({
                                    description: value,
                                })
                            }
                        />

                    </div>

                </div>

                <div className="glca-accordion__right">

                    <MediaUploadCheck>

                        <MediaUpload
                            onSelect={(media) =>
                                setAttributes({
                                    imageUrl:
                                    media.url,
                                })
                            }
                            allowedTypes={['image']}
                            render={({ open }) => (

                                <div
                                    className="glca-accordion__image-button"
                                    onClick={open}
                                >

                                    {imageUrl ? (

                                        <img
                                            src={imageUrl}
                                            alt=""
                                        />

                                    ) : (

                                        'Select Image'

                                    )}

                                </div>

                            )}
                        />

                    </MediaUploadCheck>

                </div>

            </div>

        </div>
    );
}