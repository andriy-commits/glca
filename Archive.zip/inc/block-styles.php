
<?php
/**
 * Register editor-friendly block styles so clients do not need Advanced classes.
 *
 * @package GLCA
 */

function glca_register_block_styles() {
	register_block_style(
		'core/group',
		array(
			'name'  => 'section-card',
			'label' => __( 'Section Card', 'glca' ),
		)
	);

	register_block_style(
		'core/group',
		array(
			'name'  => 'accent-panel',
			'label' => __( 'Accent Panel', 'glca' ),
		)
	);

	register_block_style(
		'core/image',
		array(
			'name'  => 'soft-rounded',
			'label' => __( 'Soft Rounded', 'glca' ),
		)
	);
}
add_action( 'init', 'glca_register_block_styles' );
