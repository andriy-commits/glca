<?php

/**
 * Register Post Types
 */

function glca_register_post_types() {

    register_post_type(
        'case-study',
        [
            'labels' => [
                'name'               => 'Case Studies',
                'singular_name'      => 'Case Study',
                'add_new'            => 'Add Case Study',
                'add_new_item'       => 'Add New Case Study',
                'edit_item'          => 'Edit Case Study',
                'new_item'           => 'New Case Study',
                'view_item'          => 'View Case Study',
                'search_items'       => 'Search Case Studies',
                'not_found'          => 'No Case Studies found',
                'not_found_in_trash' => 'No Case Studies found in Trash',
                'all_items'          => 'All Case Studies',
            ],

            'public'       => true,

            'show_in_rest' => true,

            'menu_icon'    => 'dashicons-portfolio',

            'has_archive'  => true,

            'rewrite'      => [
                'slug' => 'case-studies',
            ],

            'supports' => [
                'title',
                'editor',
                'thumbnail',
                'excerpt',
                'custom-fields',
            ],

        ]
    );


    register_post_type(
        'team_members',
        [

            'labels' => [

                'name'               => 'Team Members',

                'singular_name'      => 'Team Member',

                'add_new'            => 'Add Team Member',

                'add_new_item'       => 'Add New Team Member',

                'edit_item'          => 'Edit Team Member',

                'new_item'           => 'New Team Member',

                'view_item'          => 'View Team Member',

                'search_items'       => 'Search Team Members',

                'not_found'          => 'No Team Members found',

                'not_found_in_trash' => 'No Team Members found in Trash',

                'all_items'          => 'All Team Members',

            ],

            'public' => true,

            'show_in_rest' => true,

            'menu_icon' => 'dashicons-groups',

            'has_archive' => false,

            'rewrite' => [

                'slug' => 'team'

            ],

            'supports' => [

                'title',

                'editor',

                'thumbnail',

                'excerpt',

                'custom-fields'

            ]

        ]
    );

}

add_action(
    'init',
    'glca_register_post_types'
);

register_taxonomy(

    'cities',

    'team_members',

    [

        'labels' => [

            'name' => 'Cities',

            'singular_name' => 'City'

        ],

        'public' => true,

        'hierarchical' => true,

        'show_in_rest' => true,

        'rewrite' => [

            'slug' => 'cities'

        ]

    ]

);


register_taxonomy(

    'positions',

    'team_members',

    [

        'labels' => [

            'name' => 'Positions',

            'singular_name' => 'Position'

        ],

        'public' => true,

        'hierarchical' => true,

        'show_in_rest' => true,

        'rewrite' => [

            'slug' => 'positions'

        ]

    ]

);


register_post_type(
    'transaction',
    [
        'labels' => [
            'name'               => 'Transactions',
            'singular_name'      => 'Transaction',
            'add_new'            => 'Add Transaction',
            'add_new_item'       => 'Add New Transaction',
            'edit_item'          => 'Edit Transaction',
            'new_item'           => 'New Transaction',
            'view_item'          => 'View Transaction',
            'search_items'       => 'Search Transactions',
            'not_found'          => 'No Transactions found',
            'not_found_in_trash' => 'No Transactions found in Trash',
            'all_items'          => 'All Transactions',
        ],
        'public'       => true,
        'show_in_rest' => true,
        'menu_icon'    => 'dashicons-chart-line',
        'has_archive'  => true,
        'rewrite'      => [
            'slug' => 'transactions',
        ],
        'supports' => [
            'title',
            'editor',
            'thumbnail',
            'excerpt',
            'custom-fields',
        ],
    ]
);

// Transaction Expertise taxonomy
register_taxonomy(
    'transaction_expertise',
    'transaction',
    [
        'labels' => [
            'name'          => 'Transaction Expertise',
            'singular_name' => 'Expertise',
        ],
        'public'        => true,
        'hierarchical'  => true,
        'show_in_rest'  => true,
        'rewrite'       => [
            'slug' => 'transaction-expertise',
        ],
    ]
);

// Transaction Industry taxonomy
register_taxonomy(
    'transaction_industry',
    'transaction',
    [
        'labels' => [
            'name'          => 'Transaction Industry',
            'singular_name' => 'Industry',
        ],
        'public'        => true,
        'hierarchical'  => true,
        'show_in_rest'  => true,
        'rewrite'       => [
            'slug' => 'transaction-industry',
        ],
    ]
);
