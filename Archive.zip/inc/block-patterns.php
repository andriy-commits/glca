
<?php
/**
 * Register GLCA Gutenberg patterns.
 *
 * @package GLCA
 */

function glca_register_block_pattern_category() {
	register_block_pattern_category(
		'glca',
		array( 'label' => __( 'GLCA Sections', 'glca' ) )
	);
}
add_action( 'init', 'glca_register_block_pattern_category' );
