<?php

function glca_register_case_study_meta() {

    register_post_meta(
        'case-study',
        'case_study_blocks',
        [
            'show_in_rest' => true,

            'single' => true,

            'type' => 'string',

            'default' => '[]',

            'sanitize_callback' => function(
                $value
            ) {

                return wp_kses_post(
                    $value
                );

            },

            'auth_callback' => function() {

                return current_user_can(
                    'edit_posts'
                );

            },
        ]
    );

}

add_action(
    'init',
    'glca_register_case_study_meta'
);