<?php
/**
 * Team Members meta fields
 *
 * @package GLCA
 */

function glca_team_meta_boxes() {
    add_meta_box(
        'glca_team_details',
        __( 'Team Member Details', 'glca' ),
        'glca_team_meta_box_html',
        'team_members',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'glca_team_meta_boxes' );

function glca_team_meta_box_html( $post ) {
    wp_nonce_field( 'glca_team_meta_save', 'glca_team_meta_nonce' );

    $career_highlights = get_post_meta( $post->ID, '_career_highlights', true );
    $education         = get_post_meta( $post->ID, '_education', true );
    $vcard_url         = get_post_meta( $post->ID, '_vcard_url', true );
    $vcard_id          = get_post_meta( $post->ID, '_vcard_id', true );
    ?>

    <table class="form-table">

        <tr>
            <th><label for="career_highlights"><?php esc_html_e( 'Career Highlights', 'glca' ); ?></label></th>
            <td>
                <textarea
                    id="career_highlights"
                    name="career_highlights"
                    rows="6"
                    style="width:100%"
                ><?php echo esc_textarea( $career_highlights ); ?></textarea>
            </td>
        </tr>

        <tr>
            <th><label for="education"><?php esc_html_e( 'Education', 'glca' ); ?></label></th>
            <td>
                <textarea
                    id="education"
                    name="education"
                    rows="4"
                    style="width:100%"
                ><?php echo esc_textarea( $education ); ?></textarea>
            </td>
        </tr>

        <tr>
            <th><label><?php esc_html_e( 'Download vCard', 'glca' ); ?></label></th>
            <td>
                <input
                    type="hidden"
                    id="vcard_id"
                    name="vcard_id"
                    value="<?php echo esc_attr( $vcard_id ); ?>"
                />
                <input
                    type="text"
                    id="vcard_url"
                    name="vcard_url"
                    value="<?php echo esc_url( $vcard_url ); ?>"
                    style="width:60%;margin-right:8px"
                    readonly
                />
                <button type="button" class="button" id="glca_upload_vcard">
                    <?php esc_html_e( 'Upload vCard', 'glca' ); ?>
                </button>
                <button type="button" class="button" id="glca_remove_vcard" style="margin-left:8px">
                    <?php esc_html_e( 'Remove', 'glca' ); ?>
                </button>
            </td>
        </tr>

    </table>

    <script>
        jQuery( function( $ ) {
            var mediaUploader;

            function updateRemoveButton() {
                if ( $( '#vcard_url' ).val() ) {
                    $( '#glca_remove_vcard' ).show();
                } else {
                    $( '#glca_remove_vcard' ).hide();
                }
            }

            $( '#glca_upload_vcard' ).on( 'click', function( e ) {
                e.preventDefault();

                if ( mediaUploader ) {
                    mediaUploader.open();
                    return;
                }

                mediaUploader = wp.media({
                    title: 'Select vCard File',
                    button: { text: 'Use this file' },
                    multiple: false
                });

                mediaUploader.on( 'select', function() {
                    var attachment = mediaUploader.state().get( 'selection' ).first().toJSON();
                    $( '#vcard_url' ).val( attachment.url );
                    $( '#vcard_id' ).val( attachment.id );
                    updateRemoveButton();
                });

                mediaUploader.open();
            });

            $( '#glca_remove_vcard' ).on( 'click', function() {
                $( '#vcard_url' ).val( '' );
                $( '#vcard_id' ).val( '' );
                updateRemoveButton();
            });

            updateRemoveButton();
        } );
    </script>
    <?php
}

function glca_team_meta_save( $post_id ) {
    // Security checks
    if ( ! isset( $_POST['glca_team_meta_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['glca_team_meta_nonce'], 'glca_team_meta_save' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    if ( isset( $_POST['career_highlights'] ) ) {
        update_post_meta( $post_id, '_career_highlights', sanitize_textarea_field( $_POST['career_highlights'] ) );
    }

    if ( isset( $_POST['education'] ) ) {
        update_post_meta( $post_id, '_education', sanitize_textarea_field( $_POST['education'] ) );
    }

    if ( isset( $_POST['vcard_url'] ) ) {
        update_post_meta( $post_id, '_vcard_url', esc_url_raw( $_POST['vcard_url'] ) );
    }

    if ( isset( $_POST['vcard_id'] ) ) {
        update_post_meta( $post_id, '_vcard_id', absint( $_POST['vcard_id'] ) );
    }
}
add_action( 'save_post_team_members', 'glca_team_meta_save' );