<?php

function glca_register_case_study_acquired_block() {

    $asset_file =
        include get_template_directory()
            . '/build/case-study-acquired/index.asset.php';

    wp_register_script(
        'glca-case-study-acquired',
        get_template_directory_uri()
        . '/build/case-study-acquired/index.js',

        $asset_file['dependencies'],

        $asset_file['version']
    );

    register_block_type(
        'glca/case-study-acquired',
        [
            'editor_script' => 'glca-case-study-acquired',

            'render_callback' =>
                'glca_render_case_study_acquired_block',
        ]
    );

}

add_action(
    'init',
    'glca_register_case_study_acquired_block'
);

function glca_render_case_study_acquired_block() {

    $blocks =
        get_post_meta(
            get_the_ID(),
            'case_study_blocks',
            true
        );

    $blocks =
        json_decode(
            $blocks,
            true
        );

    if (
        empty($blocks)
        || ! is_array($blocks)
    ) {
        return '';
    }

    $title = '';

    $images = [];

    foreach (
        $blocks as $block
    ) {

        if (
            empty($title)
            && $block['type'] === 'title'
        ) {

            $title =
                $block['content'];

        }

        if (
            empty($images)
            && $block['type'] === 'images'
        ) {

            $images =
                array_slice(
                    $block['images'],
                    0,
                    2
                );

        }

    }

    ob_start();

    ?>

    <div class="case-study-acquired">

        <?php if ($images) : ?>

            <?php foreach (
                $images as $index => $image_id
            ) : ?>

                <div class="case-study-acquired__logo">

                    <?php

                    echo wp_get_attachment_image(
                        $image_id,
                        'medium'
                    );

                    ?>

                </div>

                <?php if (
                    $index === 0
                    && $title
                ) : ?>

                    <h3 class="case-study-acquired__title">

                        <?php
                        echo esc_html($title);
                        ?>

                    </h3>

                <?php endif; ?>

            <?php endforeach; ?>

        <?php endif; ?>

    </div>

    <?php

    return ob_get_clean();

}