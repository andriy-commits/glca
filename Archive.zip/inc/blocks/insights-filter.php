<?php

function glca_register_insights_filter_block(){

    register_block_type(

        get_template_directory()

        .'/build/insights-filter/blocks/insights-filter',

        [

            'render_callback'=>

                'glca_render_insights_filter'

        ]

    );

}

add_action(
    'init',
    'glca_register_insights_filter_block'
);

function glca_render_insights_filter(){

    return '<div>Insights Filter Works</div>';

}