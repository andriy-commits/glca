<?php
/**
 * Team Cards block registration
 *
 * @package GLCA
 */

function glca_register_team_cards() {
    $asset = include get_template_directory() . '/build/team-cards/index.asset.php';

    wp_register_script(
        'glca-team-cards',
        get_template_directory_uri() . '/build/team-cards/index.js',
        $asset['dependencies'],
        $asset['version']
    );

    wp_register_style(
        'glca-team-cards',
        get_template_directory_uri() . '/build/team-cards/style-index.css',
        [],
        $asset['version']
    );

    register_block_type( 'glca/team-cards', [
        'editor_script'   => 'glca-team-cards',
        'style'           => 'glca-team-cards',
        'render_callback' => 'glca_render_team_cards',
        'attributes'      => [
            'images' => [
                'type'    => 'array',
                'default' => [],
            ],
        ],
        'supports' => [
            'html' => false,
        ],
    ] );
}
add_action( 'init', 'glca_register_team_cards' );

function glca_render_team_cards( $attributes ) {
    if ( empty( $attributes['images'] ) ) {
        return '';
    }

    ob_start();
    ?>
    <div class="swiper team-swiper">
        <div class="swiper-wrapper">
            <?php foreach ( $attributes['images'] as $image ) : ?>
                <div class="swiper-slide">
                    <img src="<?php echo esc_url( $image['url'] ); ?>" alt="">
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}