<?php
/**
 * Custom Walker for Mega Menu
 *
 * @package GLCA
 */

class GLCA_Mega_Menu_Walker extends Walker_Nav_Menu {

    private $top_level_index = 0;
    private $first_top_level = true;

    public function start_lvl( &$output, $depth = 0, $args = null ) {
        if ( 0 === $depth ) {
            $output .= '<div class="submenu" data-submenu="' . $this->current_slug . '">';
        }
    }

    public function end_lvl( &$output, $depth = 0, $args = null ) {
        if ( 0 === $depth ) {
            $output .= '</div>';
        }
    }

    public function start_el( &$output, $data_object, $depth = 0, $args = null, $id = 0 ) {
        $item = $data_object;

        if ( 0 === $depth ) {

            $slug = sanitize_title( $item->title );
            $this->current_slug = $slug;

            $active_class = $this->first_top_level ? ' active' : '';
            $this->first_top_level = false;

            $has_children = in_array( 'menu-item-has-children', $item->classes );

            if ( $has_children ) {
                $output .= '<button class="mega-link' . $active_class . '" data-menu="' . esc_attr( $slug ) . '">';
                $output .= esc_html( $item->title );
                $output .= '</button>';
            } else {
                $output .= '<a class="mega-link' . $active_class . '" href="' . esc_url( $item->url ) . '">';
                $output .= esc_html( $item->title );
                $output .= '</a>';
            }

        } else {

            $output .= '<a href="' . esc_url( $item->url ) . '">' . esc_html( $item->title ) . '</a>';
        }
    }

    public function end_el( &$output, $data_object, $depth = 0, $args = null ) {

    }
}