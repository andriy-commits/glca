<?php
/**
 * Register custom Gutenberg blocks.
 *
 * @package GLCA
 */

function glca_register_blocks() {

    // Accordion
    register_block_type(
        get_template_directory() . '/build/accordion'
    );

    // Team Grid
    $asset = include get_template_directory() . '/build/team-grid/index.asset.php';
    wp_register_script(
        'glca-team-grid-editor',
        get_template_directory_uri() . '/build/team-grid/index.js',
        $asset['dependencies'],
        $asset['version']
    );
    wp_register_style(
        'glca-team-grid-style',
        get_template_directory_uri() . '/build/team-grid/style-index.css',
        [],
        $asset['version']
    );
    register_block_type(
        get_template_directory() . '/build/team-grid/blocks/team-grid',
        [
            'editor_script' => 'glca-team-grid-editor',
            'style'         => 'glca-team-grid-style',
        ]
    );

    // Transaction Grid
    $asset = include get_template_directory() . '/build/transaction-grid/index.asset.php';
    wp_register_script(
        'glca-transaction-grid-editor',
        get_template_directory_uri() . '/build/transaction-grid/index.js',
        $asset['dependencies'],
        $asset['version']
    );
    wp_register_style(
        'glca-transaction-grid-style',
        get_template_directory_uri() . '/build/transaction-grid/style-index.css',
        [],
        $asset['version']
    );
    register_block_type(
        get_template_directory() . '/build/transaction-grid/blocks/transaction-grid',
        [
            'editor_script' => 'glca-transaction-grid-editor',
            'style'         => 'glca-transaction-grid-style',
        ]
    );

}

add_action( 'init', 'glca_register_blocks' );