<?php
/**
 * Template for displaying single Transaction
 *
 * @package GLCA
 */

get_header();

while ( have_posts() ) : the_post();

    $transaction_id  = get_the_ID();
    $expertise_terms = wp_get_post_terms( $transaction_id, 'transaction_expertise' );
    $industry_terms  = wp_get_post_terms( $transaction_id, 'transaction_industry' );

    ?>

    <main id="primary" class="site-main">

        <?php // Hero ?>
        <section class="transaction-hero">
            <?php if ( has_post_thumbnail() ) : ?>
                <div class="wp-block-cover__image-background-wrap">
                    <?php the_post_thumbnail( 'full' ); ?>
                </div>
            <?php endif; ?>
            <div class="transaction-hero__inner">
                <?php the_title( '<h1 class="transaction-hero__title">', '</h1>' ); ?>
            </div>
        </section>

        <?php // Body ?>
        <section class="transaction-body">
            <div class="transaction-body__inner">

                <div class="transaction-body__content entry-content">
                    <?php the_content(); ?>
                </div>

            </div>
        </section>

    </main>

<?php
endwhile;
get_footer();