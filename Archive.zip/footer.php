<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package GLCA
 */

?>

<?php

$footer =
    get_page_by_path(
        'global-footer'
    );

if ( $footer ) {
    echo apply_filters(
        'the_content',
        $footer->post_content
    );
}

?>

<?php wp_footer(); ?>

</body>
</html>
