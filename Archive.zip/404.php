<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package GLCA
 */

get_header();
?>

    <main id="primary" class="site-main">

        <section class="error-404">
            <div class="error-404__inner">

                <div class="error-404__content">
                    <p class="error-404__code">404</p>
                    <h1 class="error-404__title">
                        <?php esc_html_e( 'Page not found', 'glca' ); ?>
                    </h1>
                    <p class="error-404__text">
                        <?php esc_html_e( "The page you're looking for doesn't exist or has been moved.", 'glca' ); ?>
                    </p>
                    <div class="wp-block-button is-style-outline-arrow error-404__button">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="wp-block-button__link">
                            <?php esc_html_e( 'Back to Home', 'glca' ); ?>
                        </a>
                    </div>
                </div>

            </div>
        </section>

    </main>

<?php get_footer(); ?>