<?php
/**
 * The header for our theme
 *
 * @package GLCA
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
    <a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'glca' ); ?></a>

    <header id="masthead" class="site-header">
        <div class="header-inner">

            <div class="header-logo">
                <?php the_custom_logo(); ?>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="header-logo__dark">
                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/logo-dark.png" alt="<?php bloginfo( 'name' ); ?>">
                </a>
            </div>

            <div class="menu-trigger-wrap">

                <button
                        class="menu-trigger"
                        aria-expanded="false"
                        aria-controls="mega-menu"
                        aria-label="Toggle Menu"
                >
                    <span class="menu-trigger__text menu-trigger__text--open">Menu</span>
                    <span class="menu-trigger__text menu-trigger__text--close" aria-hidden="true">Close</span>
                    <span class="menu-trigger__icon" aria-hidden="true">
    <svg class="icon-burger" width="17" height="12" viewBox="0 0 17 12" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="17" height="2" fill="currentColor"/>
        <rect y="5" width="17" height="2" fill="currentColor"/>
        <rect y="10" width="17" height="2" fill="currentColor"/>
    </svg>
    <svg class="icon-close" width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="0.757812" y="0" width="18" height="2" rx="1" transform="rotate(45 0.757812 0)" fill="currentColor"/>
        <rect x="0" y="12.728" width="18" height="2" rx="1" transform="rotate(-45 0 12.728)" fill="currentColor"/>
    </svg>
</span>
                </button>

                <div class="mega-menu" id="mega-menu" aria-hidden="true">
                    <div class="mega-menu__inner">
                        <div class="mega-menu__left">
                            <?php
                            wp_nav_menu( array(
                                'theme_location' => 'menu-1',
                                'walker'         => new GLCA_Mega_Menu_Walker(),
                                'items_wrap'     => '%3$s',
                                'container'      => false,
                            ) );
                            ?>
                        </div>
                        <div class="mega-menu__right"></div>
                    </div>
                </div>

            </div>

            <div class="header-cta">
                <a href="<?php echo esc_url( get_theme_mod( 'glca_header_cta_url', '/contact' ) ); ?>" class="header-button">
                    <?php echo esc_html( get_theme_mod( 'glca_header_cta_text', 'Contact' ) ); ?>
                </a>
            </div>

        </div>
    </header>