<?php
/**
 * Template for displaying single Team Member
 *
 * @package GLCA
 */

get_header();

while ( have_posts() ) : the_post();

    $member_id         = get_the_ID();
    $career_highlights = get_post_meta( $member_id, '_career_highlights', true );
    $education         = get_post_meta( $member_id, '_education', true );
    $vcard_url         = get_post_meta( $member_id, '_vcard_url', true );

    $member_cities    = wp_get_post_terms( $member_id, 'cities' );
    $member_positions = wp_get_post_terms( $member_id, 'positions' );

    $city_name     = $member_cities ? $member_cities[0]->name : '';
    $position_name = $member_positions ? $member_positions[0]->name : '';
    ?>

    <main id="primary" class="site-main">

        <?php // Hero ?>
        <section class="team-single-hero">
            <?php if ( has_post_thumbnail() ) : ?>
                <div class="team-single-hero__image">
                    <?php the_post_thumbnail( 'full' ); ?>
                </div>
            <?php endif; ?>
            <div class="team-single-hero__overlay">
                <div class="team-single-hero__inner">
                    <?php the_title( '<h1 class="team-single-hero__name">', '</h1>' ); ?>
                    <?php if ( $position_name || $city_name ) : ?>
                        <p class="team-single-hero__meta">
                            <?php echo esc_html( implode( ' / ', array_filter( [ $position_name, $city_name ] ) ) ); ?>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <?php // Body ?>
        <section class="team-single-body has-global-padding">
            <div class="team-single-body__inner">

                <?php // Left — bio + vcard ?>
                <div class="team-single-body__left">

                    <?php if ( get_the_excerpt() ) : ?>
                        <div class="team-single-body__bio">
                            <?php echo wp_kses_post( wpautop( get_post_field( 'post_excerpt', $member_id ) ) ); ?>
                        </div>
                    <?php endif; ?>

                    <?php if ( get_the_content() ) : ?>
                        <div class="team-single-body__content entry-content">
                            <?php the_content(); ?>
                        </div>
                    <?php endif; ?>

                    <?php if ( $vcard_url ) : ?>
                        <a class="team-single-body__vcard" href="<?php echo esc_url( $vcard_url ); ?>" download>
                            <?php esc_html_e( 'Download V Card', 'glca' ); ?>
                        </a>
                    <?php endif; ?>

                </div>

                <?php // Right — details ?>
                <div class="team-single-body__right">

                    <?php if ( $career_highlights ) : ?>
                        <div class="team-single-detail">
                            <h6 class="team-single-detail__title">
                                <?php esc_html_e( 'Career Highlights', 'glca' ); ?>
                            </h6>
                            <div class="team-single-detail__body">
                                <?php echo wp_kses_post( wpautop( $career_highlights ) ); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if ( $education ) : ?>
                        <div class="team-single-detail">
                            <h6 class="team-single-detail__title">
                                <?php esc_html_e( 'Education', 'glca' ); ?>
                            </h6>
                            <div class="team-single-detail__body">
                                <?php echo wp_kses_post( wpautop( $education ) ); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>

            </div>
        </section>

    </main>

<?php
endwhile;
get_footer();