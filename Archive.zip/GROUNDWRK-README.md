# GLCA Groundwrk-ready Theme Notes

This theme is based on Underscores and has been prepared for a Gutenberg-first workflow.

## Added

- `theme.json` design tokens: colors, typography, spacing, layout widths.
- Frontend/editor shared styles.
- Gutenberg pattern examples: Hero, FAQ Accordion, Card Grid.
- Custom Accordion block example using `RichText` + `InnerBlocks`.
- Block styles so editors do not need to add custom classes in Advanced settings.
- Basic accessible focus states and reduced-motion support.

## Development

```bash
npm install
npm run start
npm run build
```

## Important

The included Accordion block is a starter block. Use this pattern for additional custom blocks:

- inline editable content where possible
- `InnerBlocks` for flexible/reorderable content
- `theme.json` values instead of hardcoded colors/font sizes/spacing
- block styles or controls instead of asking clients to add custom classes

## Recommended next components

- Hero block
- Card grid block
- Vertical slider block
- CTA block
- Testimonial block
- Recent transactions/tombstone card pattern

## SCSS workflow

This theme now uses SCSS as the source of truth for custom theme styles.

Source files:

```txt
src/scss/main.scss
src/scss/base/
src/scss/components/
src/scss/blocks/
src/scss/utilities/
src/scss/settings/
```

Compiled output:

```txt
assets/css/main.css
```

Commands:

```bash
npm install
npm run start
npm run build
```

Use `theme.json` presets wherever possible:

```scss
color: var(--wp--preset--color--primary);
padding: var(--wp--preset--spacing--md);
font-size: var(--wp--preset--font-size--large);
```

Do not add random hardcoded colors, font sizes, or spacing unless the value is truly one-off.
