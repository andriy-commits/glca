<?php
/**
 * The template for displaying all single posts
 *
 * @package GLCA
 */

get_header();
?>

    <main id="primary" class="site-main">

        <?php while ( have_posts() ) : the_post(); ?>

            <?php // Hero — featured image + title ?>
            <section class="single-hero">
                <?php if ( has_post_thumbnail() ) : ?>
                    <div class="single-hero__image">
                        <?php the_post_thumbnail( 'full' ); ?>
                    </div>
                <?php endif; ?>
                <div class="single-hero__overlay">
                    <div class="single-hero__inner">
                        <?php the_title( '<h1 class="single-hero__title">', '</h1>' ); ?>
                    </div>
                </div>
            </section>

            <?php // Two-column layout ?>
            <section class="single-body has-global-padding">
                <div class="single-body__inner">

                    <div class="single-body__content">
                        <div class="entry-content">
                            <?php the_content(); ?>
                        </div>
                    </div>

                    <aside class="single-body__sidebar">
                        <h6 class="single-body__sidebar-title"><?php esc_html_e( 'Related Articles', 'glca' ); ?></h6>

                        <?php

                        $categories = get_the_category();
                        $cat_ids    = wp_list_pluck( $categories, 'term_id' );

                        $related = new WP_Query( array(
                            'post_type'           => 'post',
                            'posts_per_page'      => 4,
                            'post__not_in'        => array( get_the_ID() ),
                            'category__in'        => $cat_ids,
                            'ignore_sticky_posts' => true,
                        ) );

                        if ( $related->have_posts() ) : ?>
                            <div class="related-articles">
                                <?php while ( $related->have_posts() ) : $related->the_post(); ?>
                                    <article class="related-article">
                                        <div class="related-article__meta">
                                            <?php
                                            $cats = get_the_category();
                                            if ( $cats ) :
                                                echo '<span class="related-article__category">' . esc_html( $cats[0]->name ) . '</span>';
                                            endif;
                                            ?>
                                            <time class="related-article__date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
                                                <?php echo esc_html( get_the_date( 'F, Y' ) ); ?>
                                            </time>
                                        </div>

                                        <?php if ( has_post_thumbnail() ) : ?>
                                            <div class="related-article__image">
                                                <a href="<?php the_permalink(); ?>">
                                                    <?php the_post_thumbnail( 'medium' ); ?>
                                                </a>
                                            </div>
                                        <?php endif; ?>

                                        <h6 class="related-article__title">
                                            <?php the_title(); ?>
                                        </h6>
                                        <div class="related-article__button wp-block-button is-style-outline-arrow">
                                        <a href="<?php the_permalink(); ?>" class="wp-block-button__link has-text-color has-link-color wp-element-button related-article__link">
                                            <?php esc_html_e( 'Read Article', 'glca' ); ?>
                                        </a>
                                        </div>
                                    </article>
                                <?php endwhile; wp_reset_postdata(); ?>
                            </div>
                        <?php endif; ?>
                    </aside>

                </div>
            </section>

        <?php endwhile; ?>

    </main>

<?php get_footer(); ?>