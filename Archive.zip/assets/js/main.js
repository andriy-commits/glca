jQuery(document).ready(function ($) {

    $('.insights-template').slick({

        slidesToShow: 3,
        slidesToScroll: 1,

        arrows: true,
        prevArrow: $('.insights-loop__arrows-prev'),
        nextArrow: $('.insights-loop__arrows-next'),

        dots: true,
        appendDots: $('.insights-loop__dots'),
        customPaging: function () {
            return '<button type="button"></button>';
        },

        infinite: false,
        speed: 700,
        cssEase: 'ease',

        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 2,
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1.1,
                }
            }
        ]

    });

});



jQuery( document ).ready( function ( $ ) {

    const slider = $( '.case-studios-section-template' );
    let currentMode = window.innerWidth <= 767 ? 'horizontal' : 'vertical';

    const isMobile = () => window.innerWidth <= 767;

    function getSliderOptions() {
        const mobile = isMobile();
        return {
            slidesToShow:    1,
            slidesToScroll:  1,
            vertical:        ! mobile,
            verticalSwiping: ! mobile,
            infinite:        false,
            speed:           700,
            cssEase:         'ease',
            adaptiveHeight:  true,
            arrows:          true,
            prevArrow:       $( '.case-studios-section-loop__arrows-prev' ),
            nextArrow:       $( '.case-studios-section-loop__arrows-next' ),
            dots:            true,
            appendDots:      $( '.case-studios-section-loop__dots' ),
            customPaging:    function () {
                return '<button type="button"></button>';
            },
        };
    }

    slider.on(
        'init reInit afterChange',
        function ( event, slick, currentSlide ) {
            const i = ( currentSlide ? currentSlide : 0 ) + 1;
            $( '.case-studios-section-loop__counter .current' )
                .text( String( i ).padStart( 2, '0' ) );
            $( '.case-studios-section-loop__counter .total' )
                .text( String( slick.slideCount ).padStart( 2, '0' ) );
        }
    );

    slider.slick( getSliderOptions() );

    let resizeTimer;

    $( window ).on( 'resize', function () {
        clearTimeout( resizeTimer );

        resizeTimer = setTimeout( function () {
            const newMode = isMobile() ? 'horizontal' : 'vertical';

            if ( newMode !== currentMode ) {
                currentMode = newMode;
                slider.slick( 'unslick' );
                slider.slick( getSliderOptions() );
            } else {
                slider.slick( 'setPosition' );
            }
        }, 150 );
    } );

} );



document.addEventListener( 'DOMContentLoaded', function () {

    const sliders = document.querySelectorAll( '.team-swiper' );

    sliders.forEach( function ( slider ) {

        if ( slider.classList.contains( 'swiper-initialized' ) ) {
            return;
        }

        const slides = slider.querySelectorAll( ':scope > .wp-block-image' );

        if ( ! slides.length ) {
            return;
        }

        const wrapper = document.createElement( 'div' );
        wrapper.className = 'swiper-wrapper';

        slides.forEach( function ( slide ) {
            slide.classList.add( 'swiper-slide' );
            wrapper.appendChild( slide );
        } );

        slider.appendChild( wrapper );

        const sectionRight = slider.closest( '.team-section__right' );
        if ( ! sectionRight ) return;

        const container = sectionRight.parentNode;

        const isSafari = /^((?!chrome|android).)*safari/i.test( navigator.userAgent );
        const isIOS    = /iPad|iPhone|iPod/.test( navigator.userAgent ) && ! window.MSStream;

        new Swiper( slider, {

            effect: 'cards',
            grabCursor: true,
            slidesPerView: 1,
            centeredSlides: true,
            speed: 900,
            touchEventsTarget: 'container',
            passiveListeners: true,

            navigation: {
                prevEl: container.querySelector( '.team-section-loop__arrows-prev' ),
                nextEl: container.querySelector( '.team-section-loop__arrows-next' ),
            },

            pagination: {
                el: container.querySelector( '.team-section-loop__dots' ),
                clickable: true,
                dynamicBullets: false,
                renderBullet: function ( index, className ) {
                    return `<span class="${ className }"></span>`;
                },
            },

            cardsEffect: {
                rotate: false,
                slideShadows: false,
                perSlideOffset: 8,
                perSlideRotate: 0,
            },

            on: {

                init: updateCounter,

                slideChange: function () {
                    updateCounter.call( this );

                    if ( this.pagination && this.pagination.render ) {
                        this.pagination.render();
                        this.pagination.update();
                    }
                },

                setTranslate: function () {
                    if ( isIOS || isSafari ) return;

                    this.slides.forEach( ( slide, index ) => {
                        const offset = index - this.activeIndex;

                        const baseTransform = slide.style.transform
                            .replace( /\s*translate\([^)]*\)/g, '' )
                            .trim();

                        if ( offset <= 0 ) {
                            slide.style.transform = baseTransform;
                            return;
                        }

                        slide.style.transform = baseTransform +
                            ` translate( ${ offset * 8 }px, ${ offset * 20 }px )`;
                    } );
                },

            },

        } );

        function updateCounter() {
            const current = container.querySelector( '.current' );
            const total   = container.querySelector( '.total' );

            if ( current ) {
                current.innerText = String( this.activeIndex + 1 ).padStart( 2, '0' );
            }

            if ( total ) {
                total.innerText = String( this.slides.length ).padStart( 2, '0' );
            }
        }

    } );

} );



document.addEventListener(

    'DOMContentLoaded',

    function() {

        document

            .querySelectorAll(
                '.sectors-item'
            )

            .forEach(

                function(
                    title
                ) {

                    title.addEventListener(

                        'click',

                        function() {

                            this

                                .closest(
                                    '.sectors-item'
                                )

                                .classList

                                .toggle(
                                    'active'
                                );

                        }

                    );

                }

            );

    }

);


document.addEventListener(

    'DOMContentLoaded',

    function(){

        const rows =
            document.querySelectorAll(
                '.logos-top, .logos-bottom'
            );

        rows.forEach(

            function(row){

                const original =
                    row.innerHTML;

                while(

                    row.scrollWidth
                    <
                    window.innerWidth
                    *
                    2

                    ){

                    row.innerHTML +=
                        original;

                }

            }

        );

    }

);





//
document.addEventListener('DOMContentLoaded', function () {
    const filter = document.getElementById('insights-filter');
    const list   = document.querySelector('ul.wp-block-post-template');
    if (!filter || !list) return;

    const posts = Array.from(list.querySelectorAll('li.wp-block-post'));

    const allBtn = document.createElement('button');
    allBtn.className = 'filter-btn is-active';
    allBtn.dataset.category = 'all';
    allBtn.textContent = 'All';
    filter.appendChild(allBtn);

    const catMap = new Map(); // slug → label
    posts.forEach(post => {
        const links = post.querySelectorAll('.taxonomy-category a[href*="/category/"]');
        links.forEach(link => {
            const match = link.href.match(/\/category\/([^/]+)\//);
            if (!match) return;
            const slug = match[1];
            if (slug === 'uncategorized') return;
            if (!catMap.has(slug)) {
                catMap.set(slug, link.textContent.trim());
            }
        });
    });

    catMap.forEach((label, slug) => {
        const btn = document.createElement('button');
        btn.className = 'filter-btn';
        btn.dataset.category = slug;
        btn.textContent = label;
        filter.appendChild(btn);
    });

    filter.addEventListener('click', e => {
        const btn = e.target.closest('.filter-btn');
        if (!btn) return;
        filter.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('is-active'));
        btn.classList.add('is-active');
        const selected = btn.dataset.category;
        posts.forEach(post => {
            post.style.display = (selected === 'all' || post.classList.contains('category-' + selected)) ? '' : 'none';
        });
    });
});

document.addEventListener( 'DOMContentLoaded', () => {

    const grid   = document.querySelector( '.team-grid__grid' );
    const modal  = document.getElementById( 'team-modal' );
    if ( ! grid || ! modal ) return;

    const modalImage     = modal.querySelector( '.team-modal__image' );
    const modalName      = modal.querySelector( '.team-modal__name' );
    const modalMeta      = modal.querySelector( '.team-modal__meta' );
    const modalExcerpt   = modal.querySelector( '.team-modal__excerpt' );
    const modalCareer    = modal.querySelector( '.team-modal__career' );
    const modalEdu       = modal.querySelector( '.team-modal__education' );
    const modalVcard     = modal.querySelector( '.team-modal__vcard' );
    const modalVcardWrap = modal.querySelector( '.team-modal__vcard-wrap' );
    const modalClose     = modal.querySelector( '.team-modal__close' );
    const modalBackdrop  = modal.querySelector( '.team-modal__backdrop' );
    const modalInner     = modal.querySelector( '.team-modal__inner' );

    // Active filters
    const activeFilters = { position: 'all', city: 'all' };

    // Dropdown filters
    document.querySelectorAll( '.team-grid__select' ).forEach( select => {
        select.addEventListener( 'change', () => {
            activeFilters[ select.dataset.filter ] = select.value;
            applyFilters();
        } );
    } );

    function applyFilters() {
        document.querySelectorAll( '.team-grid__member' ).forEach( member => {
            const memberCities    = member.dataset.city ? member.dataset.city.split( ' ' ) : [];
            const memberPositions = member.dataset.position ? member.dataset.position.split( ' ' ) : [];

            const cityMatch     = activeFilters.city === 'all' || memberCities.includes( activeFilters.city );
            const positionMatch = activeFilters.position === 'all' || memberPositions.includes( activeFilters.position );

            member.classList.toggle( 'is-hidden', ! ( cityMatch && positionMatch ) );
        } );
    }

    // Open modal
    function openModal( member ) {
        const data = member.querySelector( '.team-grid__modal-data' );
        if ( ! data ) return;

        const name      = data.querySelector( '.modal-name' ).textContent;
        const position  = data.querySelector( '.modal-position' ).textContent;
        const city      = data.querySelector( '.modal-city' ).textContent;
        const excerpt   = data.querySelector( '.modal-excerpt' ).textContent;
        const career    = data.querySelector( '.modal-career' ).textContent;
        const education = data.querySelector( '.modal-education' ).textContent;
        const vcard     = data.querySelector( '.modal-vcard' ).textContent.trim();
        const image     = data.querySelector( '.modal-image' ).textContent.trim();

        modalName.textContent    = name;
        modalMeta.textContent    = [ position, city ].filter( Boolean ).join( ' / ' );
        modalExcerpt.textContent = excerpt;
        modalCareer.textContent  = career;
        modalEdu.textContent     = education;

        modalImage.innerHTML = image
            ? `<img src="${ image }" alt="${ name }">`
            : '';

        if ( vcard ) {
            modalVcard.href = vcard;
            modalVcard.setAttribute( 'download', '' );
            modalVcardWrap.classList.remove( 'is-hidden' );
        } else {
            modalVcardWrap.classList.add( 'is-hidden' );
        }

        modal.classList.remove( 'is-closing' );
        modal.classList.add( 'is-open' );
        modal.setAttribute( 'aria-hidden', 'false' );
        document.body.style.overflow = 'hidden';
        modalClose.focus();
    }

    // Close modal
    function closeModal() {
        modal.classList.add( 'is-closing' );

        modalInner.addEventListener(
            'transitionend',
            () => {
                modal.classList.remove( 'is-open', 'is-closing' );
                modal.setAttribute( 'aria-hidden', 'true' );
                document.body.style.overflow = '';
            },
            { once: true }
        );
    }

    // Member click
    grid.addEventListener( 'click', e => {
        const member = e.target.closest( '.team-grid__member' );
        if ( member ) openModal( member );
    } );

    // Keyboard support
    grid.addEventListener( 'keydown', e => {
        if ( e.key === 'Enter' || e.key === ' ' ) {
            const member = e.target.closest( '.team-grid__member' );
            if ( member ) {
                e.preventDefault();
                openModal( member );
            }
        }
    } );

    modalClose.addEventListener( 'click', closeModal );
    modalBackdrop.addEventListener( 'click', closeModal );

    document.addEventListener( 'keydown', e => {
        if ( e.key === 'Escape' ) closeModal();
    } );

    // Toggle detail sections
    modal.addEventListener( 'click', e => {
        const toggle = e.target.closest( '.team-modal__detail-toggle' );
        if ( ! toggle ) return;

        const expanded = toggle.getAttribute( 'aria-expanded' ) === 'true';
        const body     = toggle.nextElementSibling;

        toggle.setAttribute( 'aria-expanded', String( ! expanded ) );
        body.hidden = expanded;
    } );

} );

function moveSectorsButtons() {
    document.querySelectorAll( '.sectors-item' ).forEach( item => {
        const btn = item.querySelector( '.sectors-item__button' );
        if ( ! btn ) return;

        if ( window.innerWidth <= 767 ) {

            if ( item.lastElementChild !== btn ) {
                item.appendChild( btn );
            }
        } else {

            const top = item.querySelector( '.sectors-item__top' );
            if ( top && ! top.contains( btn ) ) {
                top.appendChild( btn );
            }
        }
    } );
}

document.addEventListener( 'DOMContentLoaded', moveSectorsButtons );
window.addEventListener( 'resize', moveSectorsButtons );

document.querySelectorAll( '.wp-block-query-pagination-next' ).forEach( btn => {
    btn.innerHTML = `<svg width="14" height="12" viewBox="0 0 14 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.0765 5.80177L6.71725 1.44851C6.54742 1.27851 6.46342 1.0796 6.46525 0.851766C6.46725 0.623932 6.55125 0.425015 6.71725 0.255015C6.88725 0.0850153 7.08617 1.52588e-05 7.314 1.52588e-05C7.54183 1.52588e-05 7.74075 0.0850153 7.91075 0.255015L12.8608 5.19902C12.9521 5.29035 13.0184 5.38568 13.0598 5.48501C13.1009 5.58418 13.1215 5.68977 13.1215 5.80177C13.1215 5.91377 13.1009 6.01935 13.0598 6.11852C13.0184 6.21785 12.9521 6.31318 12.8608 6.40451L7.91075 11.3485C7.74075 11.5185 7.54183 11.6035 7.314 11.6035C7.08617 11.6035 6.88725 11.5185 6.71725 11.3485C6.54742 11.1785 6.4625 10.9796 6.4625 10.7518C6.4625 10.5239 6.54742 10.325 6.71725 10.155L11.0765 5.80177ZM4.614 5.80177L0.25475 1.44851C0.0849167 1.27851 0.000916301 1.0796 0.00274963 0.851766C0.00474963 0.623932 0.0907498 0.425015 0.26075 0.255015C0.43075 0.0850153 0.629666 1.52588e-05 0.8575 1.52588e-05C1.08533 1.52588e-05 1.28425 0.0850153 1.45425 0.255015L6.39825 5.19902C6.48958 5.29035 6.55592 5.38568 6.59725 5.48501C6.63842 5.58418 6.659 5.68977 6.659 5.80177C6.659 5.91377 6.63842 6.01935 6.59725 6.11852C6.55592 6.21785 6.48958 6.31318 6.39825 6.40451L1.45425 11.3485C1.28425 11.5185 1.08533 11.6035 0.8575 11.6035C0.629666 11.6035 0.43075 11.5185 0.26075 11.3485C0.0869165 11.1785 0 10.9796 0 10.7518C0 10.5239 0.0869165 10.323 0.26075 10.149L4.614 5.80177Z" fill="currentColor"/></svg>`;
} );

document.querySelectorAll( '.wp-block-query-pagination-previous' ).forEach( btn => {
    btn.innerHTML = `<svg width="14" height="12" viewBox="0 0 14 12" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform:scaleX(-1)"><path d="M11.0765 5.80177L6.71725 1.44851C6.54742 1.27851 6.46342 1.0796 6.46525 0.851766C6.46725 0.623932 6.55125 0.425015 6.71725 0.255015C6.88725 0.0850153 7.08617 1.52588e-05 7.314 1.52588e-05C7.54183 1.52588e-05 7.74075 0.0850153 7.91075 0.255015L12.8608 5.19902C12.9521 5.29035 13.0184 5.38568 13.0598 5.48501C13.1009 5.58418 13.1215 5.68977 13.1215 5.80177C13.1215 5.91377 13.1009 6.01935 13.0598 6.11852C13.0184 6.21785 12.9521 6.31318 12.8608 6.40451L7.91075 11.3485C7.74075 11.5185 7.54183 11.6035 7.314 11.6035C7.08617 11.6035 6.88725 11.5185 6.71725 11.3485C6.54742 11.1785 6.4625 10.9796 6.4625 10.7518C6.4625 10.5239 6.54742 10.325 6.71725 10.155L11.0765 5.80177ZM4.614 5.80177L0.25475 1.44851C0.0849167 1.27851 0.000916301 1.0796 0.00274963 0.851766C0.00474963 0.623932 0.0907498 0.425015 0.26075 0.255015C0.43075 0.0850153 0.629666 1.52588e-05 0.8575 1.52588e-05C1.08533 1.52588e-05 1.28425 0.0850153 1.45425 0.255015L6.39825 5.19902C6.48958 5.29035 6.55592 5.38568 6.59725 5.48501C6.63842 5.58418 6.659 5.68977 6.659 5.80177C6.659 5.91377 6.63842 6.01935 6.59725 6.11852C6.55592 6.21785 6.48958 6.31318 6.39825 6.40451L1.45425 11.3485C1.28425 11.5185 1.08533 11.6035 0.8575 11.6035C0.629666 11.6035 0.43075 11.5185 0.26075 11.3485C0.0869165 11.1785 0 10.9796 0 10.7518C0 10.5239 0.0869165 10.323 0.26075 10.149L4.614 5.80177Z" fill="currentColor"/></svg>`;
} );



document.querySelectorAll( '.transaction-grid' ).forEach( grid => {

    const gridEl       = grid.querySelector( '.transaction-grid__grid' );
    const emptyEl      = grid.querySelector( '.transaction-grid__empty' );
    const numbersEl    = grid.querySelector( '.transaction-grid__pagination-numbers' );
    const arrowsEl     = grid.querySelector( '.transaction-grid__pagination-arrows' );
    const defaultPosts = parseInt( grid.dataset.postsPerPage ) || 12;

    let currentPage      = 1;
    let currentExpertise = '';
    let currentIndustry  = '';
    let isFirstLoad      = true;

    function getPostsPerPage() {
        if ( window.innerWidth <= 767 ) return 6;
        if ( window.innerWidth <= 1024 ) return 9;
        return defaultPosts;
    }

    function fetchTransactions( paged = 1 ) {
        grid.classList.add( 'is-loading' );

        const data = new FormData();
        data.append( 'action',         'glca_transaction_grid' );
        data.append( 'nonce',          glcaAjax.nonce );
        data.append( 'posts_per_page', getPostsPerPage() );
        data.append( 'paged',          paged );
        data.append( 'expertise',      currentExpertise );
        data.append( 'industry',       currentIndustry );

        fetch( glcaAjax.url, { method: 'POST', body: data } )
            .then( r => r.json() )
            .then( res => {
                if ( ! res.success ) return;

                const { cards, max_pages, paged } = res.data;

                currentPage = paged;

                gridEl.innerHTML = cards.join( '' );
                emptyEl.style.display = cards.length ? 'none' : '';

                renderNumbers( max_pages, paged );
                renderArrows( max_pages, paged );

                // Scroll only on pagination click, not on first load or resize
                if ( ! isFirstLoad ) {
                    grid.scrollIntoView( { behavior: 'smooth', block: 'start' } );
                }

                isFirstLoad = false;
                grid.classList.remove( 'is-loading' );
            } );
    }

    function renderNumbers( total, paged ) {
        let html = '';

        for ( let i = 1; i <= total; i++ ) {
            if ( i === 1 || i === total || ( i >= paged - 1 && i <= paged + 1 ) ) {
                html += `<a href="#" class="transaction-grid__pagination-num${ i === paged ? ' is-active' : '' }"
                    ${ i === paged ? 'aria-current="page"' : '' }
                    data-page="${ i }">${ String( i ).padStart( 2, '0' ) }</a>`;
            } else if ( i === paged - 2 || i === paged + 2 ) {
                html += `<span class="transaction-grid__pagination-ellipsis">…</span>`;
            }
        }

        numbersEl.innerHTML = html;

        numbersEl.querySelectorAll( 'a' ).forEach( a => {
            a.addEventListener( 'click', e => {
                e.preventDefault();
                isFirstLoad = false;
                fetchTransactions( parseInt( a.dataset.page ) );
            } );
        } );
    }

    function renderArrows( total, paged ) {
        const svgNext = `<svg width="14" height="12" viewBox="0 0 14 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.61359 5.80175L0.254344 1.4485C0.0845107 1.2785 0.000510169 1.07958 0.00234314 0.85175C0.00434396 0.623916 0.0903435 0.425 0.260344 0.255C0.430344 0.0849997 0.62926 -5.46035e-07 0.857094 -5.36076e-07C1.08493 -5.26118e-07 1.28384 0.0849998 1.45384 0.255L6.39784 5.199C6.48918 5.29033 6.55551 5.38567 6.59684 5.485C6.63801 5.58417 6.65859 5.68975 6.65859 5.80175C6.65859 5.91375 6.63801 6.01933 6.59684 6.1185C6.55551 6.21783 6.48918 6.31317 6.39784 6.4045L1.45384 11.3485C1.28384 11.5185 1.08493 11.6035 0.857093 11.6035C0.62926 11.6035 0.430343 11.5185 0.260343 11.3485C0.0865102 11.1785 -0.000406745 10.9796 -0.000406735 10.7517C-0.000406725 10.5239 0.0865102 10.323 0.260343 10.149L4.61359 5.80175ZM11.0761 5.80175L6.71684 1.4485C6.54701 1.2785 6.46301 1.07958 6.46484 0.85175C6.46684 0.623917 6.55084 0.425 6.71684 0.255C6.88684 0.085 7.08576 -2.63813e-07 7.31359 -2.53854e-07C7.54143 -2.43895e-07 7.74034 0.0850001 7.91034 0.255L12.8603 5.199C12.9517 5.29033 13.018 5.38567 13.0593 5.485C13.1005 5.58417 13.1211 5.68975 13.1211 5.80175C13.1211 5.91375 13.1005 6.01933 13.0593 6.1185C13.0184 6.21785 12.9521 6.31318 12.8608 6.40451L7.91034 11.3485C7.74034 11.5185 7.54143 11.6035 7.31359 11.6035C7.08576 11.6035 6.88684 11.5185 6.71684 11.3485C6.54701 11.1785 6.46209 10.9796 6.46209 10.7517C6.46209 10.5239 6.54701 10.325 6.71684 10.155L11.0761 5.80175Z" fill="#DFF2FF"/></svg>`;

        const svgPrev = `<svg width="14" height="12" viewBox="0 0 14 12" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform:scaleX(-1)"><path d="M4.61359 5.80175L0.254344 1.4485C0.0845107 1.2785 0.000510169 1.07958 0.00234314 0.85175C0.00434396 0.623916 0.0903435 0.425 0.260344 0.255C0.430344 0.0849997 0.62926 -5.46035e-07 0.857094 -5.36076e-07C1.08493 -5.26118e-07 1.28384 0.0849998 1.45384 0.255L6.39784 5.199C6.48918 5.29033 6.55551 5.38567 6.59684 5.485C6.63801 5.58417 6.65859 5.68975 6.65859 5.80175C6.65859 5.91375 6.63801 6.01933 6.59684 6.1185C6.55551 6.21783 6.48918 6.31317 6.39784 6.4045L1.45384 11.3485C1.28384 11.5185 1.08493 11.6035 0.857093 11.6035C0.62926 11.6035 0.430343 11.5185 0.260343 11.3485C0.0865102 11.1785 -0.000406745 10.9796 -0.000406735 10.7517C-0.000406725 10.5239 0.0865102 10.323 0.260343 10.149L4.61359 5.80175ZM11.0761 5.80175L6.71684 1.4485C6.54701 1.2785 6.46301 1.07958 6.46484 0.85175C6.46684 0.623917 6.55084 0.425 6.71684 0.255C6.88684 0.085 7.08576 -2.63813e-07 7.31359 -2.53854e-07C7.54143 -2.43895e-07 7.74034 0.0850001 7.91034 0.255L12.8603 5.199C12.9517 5.29033 13.018 5.38567 13.0593 5.485C13.1005 5.58417 13.1211 5.68975 13.1211 5.80175C13.1211 5.91375 13.1005 6.01933 13.0593 6.1185C13.0184 6.21785 12.9521 6.31318 12.8608 6.40451L7.91034 11.3485C7.74034 11.5185 7.54143 11.6035 7.31359 11.6035C7.08576 11.6035 6.88684 11.5185 6.71684 11.3485C6.54701 11.1785 6.46209 10.9796 6.46209 10.7517C6.46209 10.5239 6.54701 10.325 6.71684 10.155L11.0761 5.80175Z" fill="#DFF2FF"/></svg>`;

        let html = '';

        if ( paged > 1 ) {
            html += `<a href="#" class="transaction-grid__pagination-arrow is-prev" aria-label="Previous page" data-page="${ paged - 1 }">${ svgPrev }</a>`;
        }

        if ( paged < total ) {
            html += `<a href="#" class="transaction-grid__pagination-arrow is-next" aria-label="Next page" data-page="${ paged + 1 }">${ svgNext }</a>`;
        }

        arrowsEl.innerHTML = html;

        arrowsEl.querySelectorAll( 'a' ).forEach( a => {
            a.addEventListener( 'click', e => {
                e.preventDefault();
                isFirstLoad = false;
                fetchTransactions( parseInt( a.dataset.page ) );
            } );
        } );
    }

    // Filter change
    grid.querySelectorAll( '.transaction-grid__select' ).forEach( select => {
        select.addEventListener( 'change', () => {
            if ( select.dataset.filter === 'expertise' ) {
                currentExpertise = select.value;
            } else {
                currentIndustry = select.value;
            }
            isFirstLoad = false;
            fetchTransactions( 1 );
        } );
    } );

    // Re-fetch on resize (debounced)
    let resizeTimer;
    window.addEventListener( 'resize', () => {
        clearTimeout( resizeTimer );
        resizeTimer = setTimeout( () => {
            fetchTransactions( currentPage );
        }, 300 );
    } );

    // Initial load
    fetchTransactions( 1 );

} );