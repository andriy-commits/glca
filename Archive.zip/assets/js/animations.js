(function () {
  const items = document.querySelectorAll('.glca-fade-up');
  if (!items.length || !('IntersectionObserver' in window)) {
    items.forEach((item) => item.classList.add('is-visible'));
    return;
  }
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.16 });
  items.forEach((item) => observer.observe(item));
}());


// Parallax Hero
document.addEventListener( 'DOMContentLoaded', () => {

  const heroes = document.querySelectorAll( '.hero-parallax' );
  if ( ! heroes.length ) return;

  function onScroll() {
    const scrollY = window.scrollY;

    heroes.forEach( hero => {
      const rect   = hero.getBoundingClientRect();
      const heroTop = hero.offsetTop;

      // Only animate when hero is visible
      if ( rect.bottom < 0 || rect.top > window.innerHeight ) return;

      const progress = scrollY - heroTop;

      // Background — slowest
      const bg = hero.querySelector( '.wp-block-cover__image-background' );
      if ( bg ) {
        bg.style.transform = `translateY(${ progress * 0.1 }px)`;

      }

      // Heading — medium
      const heading = hero.querySelector( 'h1, h2' );
      if ( heading ) {
        heading.style.transform = `translateY(${ progress * 0.3 }px)`;

      }

      // Paragraph — fastest
      const para = hero.querySelector( 'p' );
      if ( para ) {
        para.style.transform = `translateY(${ progress * 0.5 }px)`;
      }

      // Fade out
      const inner = hero.querySelector( '.wp-block-cover__inner-container' );
      if ( inner ) {
        const opacity = Math.max( 0, 1 - scrollY / ( hero.offsetHeight * 0.8 ) );
        inner.style.opacity = opacity;
      }
    } );
  }

  window.addEventListener( 'scroll', onScroll, { passive: true } );
  onScroll();

} );



// Cities text hover → image effect
document.addEventListener( 'DOMContentLoaded', () => {
  const cityLinks = document.querySelectorAll( 'a[href*="#newyork"], a[href*="#denver"], a[href*="#losangeles"], a[href*="#sanfrancisco"]' );
  const cityImages = document.querySelectorAll( '.cities-item' );

  const map = {
    'newyork':       0,
    'denver':        1,
    'losangeles':    2,
    'sanfrancisco':  3,
  };

  cityLinks.forEach( link => {
    const hash = link.getAttribute( 'href' ).replace( /.*#/, '' ).toLowerCase().replace( /\s/g, '' );
    const index = map[ hash ];
    const img = cityImages[ index ];

    if ( img === undefined ) return;

    link.addEventListener( 'mouseenter', () => {
      img.classList.add( 'is-hover' );
    } );

    link.addEventListener( 'mouseleave', () => {
      img.classList.remove( 'is-hover' );
    } );
  } );
} );


