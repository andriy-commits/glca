document.addEventListener(
    'DOMContentLoaded',
    function() {

        console.log(
            'team gallery init'
        );

        const gallery =
            document.querySelector(
                '.team-section__gallery'
            );

        console.log(
            'gallery:',
            gallery
        );

        if (
            ! gallery
        ) {

            console.log(
                'gallery not found'
            );

            return;

        }

        gallery.classList.add(
            'swiper'
        );

        const wrapper =
            document.createElement(
                'div'
            );

        wrapper.className =
            'swiper-wrapper';

        const slides =
            gallery.querySelectorAll(
                '.wp-block-image'
            );

        console.log(
            'slides:',
            slides.length
        );

        slides.forEach(
            (slide) => {

                slide.classList.add(
                    'swiper-slide'
                );

                wrapper.appendChild(
                    slide
                );

            }
        );

        gallery.appendChild(
            wrapper
        );

        console.log(
            'creating swiper'
        );

        const swiper =
            new Swiper(
                '.team-section__gallery',
                {

                    modules: [
                        EffectCards
                    ],

                    effect:
                        'cards',

                    grabCursor:
                        true,

                    cardsEffect: {

                        rotate:
                            false,

                        slideShadows:
                            false,

                    },

                }
            );

        console.log(
            'swiper:',
            swiper
        );

    }
);