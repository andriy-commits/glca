<?php

/*
Template Name: Industries Page
*/

get_header();

?>

    <main class="industries-page">

        <?php

        while (
        have_posts()
        ) :

            the_post();

            the_content();

        endwhile;

        ?>

    </main>

<?php

get_footer();