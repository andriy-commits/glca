<?php

/*
Template Name: Industry - Single
*/

get_header();

?>

    <main class="industry-single">

        <?php

        while (
        have_posts()
        ) :

            the_post();

            the_content();

        endwhile;

        ?>

    </main>

<?php

get_footer();