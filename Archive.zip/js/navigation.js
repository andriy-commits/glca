/**
 * File navigation.js.
 * @package GLCA
 */

( function () {
	const siteNavigation = document.getElementById( 'site-navigation' );

	if ( siteNavigation ) {
		const button = siteNavigation.getElementsByTagName( 'button' )[ 0 ];
		const menu   = siteNavigation.getElementsByTagName( 'ul' )[ 0 ];

		if ( button && menu ) {
			if ( ! menu.classList.contains( 'nav-menu' ) ) {
				menu.classList.add( 'nav-menu' );
			}

			button.addEventListener( 'click', function () {
				siteNavigation.classList.toggle( 'toggled' );
				const expanded = button.getAttribute( 'aria-expanded' ) === 'true';
				button.setAttribute( 'aria-expanded', String( ! expanded ) );
			} );

			document.addEventListener( 'click', function ( event ) {
				if ( ! siteNavigation.contains( event.target ) ) {
					siteNavigation.classList.remove( 'toggled' );
					button.setAttribute( 'aria-expanded', 'false' );
				}
			} );
		}
	}
} () );

document.addEventListener( 'DOMContentLoaded', () => {

	// --- Mega Menu ---
	const trigger     = document.querySelector( '.menu-trigger' );
	const megaMenu    = document.querySelector( '.mega-menu' );
	const triggerWrap = document.querySelector( '.menu-trigger-wrap' );

	if ( ! trigger || ! megaMenu ) return;

	// Move submenus from left to right column
	const megaRight = document.querySelector( '.mega-menu__right' );
	document.querySelectorAll( '.mega-menu__left .submenu' ).forEach( submenu => {
		submenu.classList.remove( 'active' );
		megaRight.appendChild( submenu );
	} );

	// Toggle menu open/close
	trigger.addEventListener( 'click', ( e ) => {
		if ( e.target.closest( '.mega-menu' ) ) return;

		const expanded = trigger.getAttribute( 'aria-expanded' ) === 'true';
		trigger.setAttribute( 'aria-expanded', String( ! expanded ) );
		megaMenu.classList.toggle( 'active' );
		megaMenu.setAttribute( 'aria-hidden', String( expanded ) );
		triggerWrap.classList.toggle( 'is-open' );
	} );

	// Close on outside click
	document.addEventListener( 'click', ( e ) => {
		if ( ! triggerWrap.contains( e.target ) ) {
			trigger.setAttribute( 'aria-expanded', 'false' );
			megaMenu.classList.remove( 'active' );
			megaMenu.setAttribute( 'aria-hidden', 'true' );
			triggerWrap.classList.remove( 'is-open' );
		}
	} );

	const isMobile = () => window.innerWidth <= 767;

	// Mega links — hover on desktop, click on mobile
	document.querySelectorAll( '.mega-link[data-menu]' ).forEach( link => {
		let hideTimeout;

		link.addEventListener( 'mouseenter', () => {
			if ( isMobile() ) return;

			clearTimeout( hideTimeout );
			document.querySelectorAll( '.mega-link' ).forEach( l => l.classList.remove( 'active' ) );
			link.classList.add( 'active' );
			document.querySelectorAll( '.submenu' ).forEach( s => {
				s.classList.remove( 'active' );
				s.style.paddingTop = '';
			} );

			const target = document.querySelector( `[data-submenu="${ link.dataset.menu }"]` );
			if ( target ) {
				target.classList.add( 'active' );

				const linkRect  = link.getBoundingClientRect();
				const rightRect = megaRight.getBoundingClientRect();
				const offset    = Math.max( 0, linkRect.top - rightRect.top );
				target.style.paddingTop = offset + 'px';
			}
		} );

		link.addEventListener( 'mouseleave', () => {
			if ( isMobile() ) return;

			const target = document.querySelector( `[data-submenu="${ link.dataset.menu }"]` );
			hideTimeout = setTimeout( () => {
				if ( target && target.matches( ':hover' ) ) return;
				link.classList.remove( 'active' );
				if ( target ) target.classList.remove( 'active' );
			}, 200 );
		} );

		link.addEventListener( 'click', () => {
			if ( ! isMobile() ) return;

			const isActive = link.classList.contains( 'active' );

			document.querySelectorAll( '.mega-link' ).forEach( l => l.classList.remove( 'active' ) );
			document.querySelectorAll( '.submenu' ).forEach( s => s.classList.remove( 'active' ) );

			if ( ! isActive ) {
				link.classList.add( 'active' );
				const target = document.querySelector( `[data-submenu="${ link.dataset.menu }"]` );
				if ( target ) target.classList.add( 'active' );
			}
		} );
	} );

	// Keep submenu active when hovering it on desktop
	document.querySelectorAll( '.submenu' ).forEach( submenu => {
		submenu.addEventListener( 'mouseenter', () => {
			if ( isMobile() ) return;

			const slug = submenu.dataset.submenu;
			const link = document.querySelector( `.mega-link[data-menu="${ slug }"]` );
			if ( link ) link.classList.add( 'active' );
		} );

		submenu.addEventListener( 'mouseleave', () => {
			if ( isMobile() ) return;

			submenu.classList.remove( 'active' );
			const slug = submenu.dataset.submenu;
			const link = document.querySelector( `.mega-link[data-menu="${ slug }"]` );
			if ( link ) link.classList.remove( 'active' );
		} );
	} );

	// --- Insights items click ---
	document.querySelectorAll( '.insights-item' ).forEach( item => {
		const link = item.querySelector( '.insights-item__read-more' );
		if ( ! link ) return;

		item.addEventListener( 'click', ( event ) => {
			if ( event.target.closest( 'a' ) ) return;
			window.location.href = link.href;
		} );
	} );

} );

document.querySelectorAll( '.transaction-grid__select' ).forEach( select => {
	function resize() {
		const tmp = document.createElement( 'select' );
		tmp.style.visibility = 'hidden';
		tmp.style.position = 'absolute';
		tmp.style.fontFamily = getComputedStyle( select ).fontFamily;
		tmp.style.fontSize = getComputedStyle( select ).fontSize;

		const opt = document.createElement( 'option' );
		opt.textContent = select.options[ select.selectedIndex ].textContent.trim();
		tmp.appendChild( opt );
		document.body.appendChild( tmp );

		select.style.width = ( tmp.offsetWidth + 6 ) + 'px';
		document.body.removeChild( tmp );
	}

	resize();
	select.addEventListener( 'change', resize );
} );

document.querySelectorAll( '.team-grid__select' ).forEach( select => {
	function resize() {
		const tmp = document.createElement( 'select' );
		tmp.style.visibility = 'hidden';
		tmp.style.position = 'absolute';
		tmp.style.fontFamily = getComputedStyle( select ).fontFamily;
		tmp.style.fontSize = getComputedStyle( select ).fontSize;

		const opt = document.createElement( 'option' );
		opt.textContent = select.options[ select.selectedIndex ].textContent.trim();
		tmp.appendChild( opt );
		document.body.appendChild( tmp );

		select.style.width = ( tmp.offsetWidth + 8 ) + 'px';
		document.body.removeChild( tmp );
	}

	resize();
	select.addEventListener( 'change', resize );
} );