const { registerPlugin } =
    wp.plugins;

const {
    PluginDocumentSettingPanel,
} = wp.editPost;

const {
    Button,
    TextControl,
    TextareaControl,
} = wp.components;

const {
    useSelect,
    useDispatch,
} = wp.data;

const { Fragment } = wp.element;

function CaseStudySidebar() {

    const meta = useSelect(
        (select) => {

            return select('core/editor')
                .getEditedPostAttribute('meta');

        },
        []
    );

    const { editPost } =
        useDispatch('core/editor');

    let blocks = [];

    try {

        blocks = JSON.parse(
            meta.case_study_blocks || '[]'
        );

    } catch (e) {}

    function updateBlocks(newBlocks) {

        editPost({
            meta: {
                ...meta,
                case_study_blocks:
                    JSON.stringify(newBlocks),
            },
        });

    }

    function addTitle() {

        updateBlocks([
            ...blocks,
            {
                type: 'title',
                content: '',
            },
        ]);

    }

    function addBlurb() {

        updateBlocks([
            ...blocks,
            {
                type: 'blurb',
                content: '',
            },
        ]);

    }

    return (
        <PluginDocumentSettingPanel
            name="case-study-panel"
            title="Case Study Content"
        >

            <Button
                variant="primary"
                onClick={ addTitle }
            >
                Add Title
            </Button>

            <Button
                variant="secondary"
                onClick={ addBlurb }
                style={{
                    marginTop: '10px'
                }}
            >
                Add Blurb
            </Button>

            {blocks.map(
                (block, index) => {

                    return (
                        <Fragment
                            key={ index }
                        >

                            {block.type === 'title' && (

                                <TextControl
                                    label="Title"
                                    value={
                                        block.content
                                    }
                                    onChange={
                                        (value) => {

                                            const updated =
                                                [...blocks];

                                            updated[index]
                                                .content =
                                                value;

                                            updateBlocks(
                                                updated
                                            );

                                        }
                                    }
                                />

                            )}

                            {block.type === 'blurb' && (

                                <TextareaControl
                                    label="Blurb"
                                    value={
                                        block.content
                                    }
                                    onChange={
                                        (value) => {

                                            const updated =
                                                [...blocks];

                                            updated[index]
                                                .content =
                                                value;

                                            updateBlocks(
                                                updated
                                            );

                                        }
                                    }
                                />

                            )}

                        </Fragment>
                    );

                }
            )}

        </PluginDocumentSettingPanel>
    );

}

registerPlugin(
    'glca-case-study-sidebar',
    {
        render: CaseStudySidebar,
    }
);