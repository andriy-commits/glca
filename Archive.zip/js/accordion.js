document.addEventListener('DOMContentLoaded', () => {

    const accordions =
        document.querySelectorAll(
            '.accordion-grid'
        );

    accordions.forEach((accordion) => {

        const trigger =
            accordion.querySelector(
                '.accordion-title'
            );

        if (!trigger) {
            return;
        }

        trigger.addEventListener(
            'click',
            () => {

                accordion.classList.toggle(
                    'is-open'
                );

            }
        );

    });

});